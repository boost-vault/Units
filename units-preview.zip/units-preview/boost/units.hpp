
//  Boost Units library header file  ---------------------------------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_HPP
#  define BOOST_UNITS_HPP

#  include <boost/units/base_dimension.hpp>
#  include <boost/units/derived_dimension.hpp>

#  include <boost/units/quantity.hpp>
#  include <boost/units/measure.hpp>

#  include <boost/units/length_unit.hpp>
#  include <boost/units/mass_unit.hpp>
#  include <boost/units/time_unit.hpp>
#  include <boost/units/temperature_units.hpp>
#  include <boost/units/electricity_units.hpp>
#  include <boost/units/substance_units.hpp>
#  include <boost/units/luminosity_units.hpp>
#  include <boost/units/angle_unit.hpp>

#  include <boost/units/derived_unit.hpp>

#  include <boost/units/metric.hpp>

#endif // !defined BOOST_UNITS_HPP

