
//  Boost Units library derived_dimension.hpp header file  -----------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_DERIVED_DIMENSION_HPP
#  define BOOST_UNITS_DERIVED_DIMENSION_HPP

#  include <boost/units/derived_dimension/acceleration.hpp>
#  include <boost/units/derived_dimension/area.hpp>
#  include <boost/units/derived_dimension/density.hpp>
#  include <boost/units/derived_dimension/force.hpp>
#  include <boost/units/derived_dimension/power.hpp>
#  include <boost/units/derived_dimension/velocity.hpp>
#  include <boost/units/derived_dimension/volume.hpp>
#  include <boost/units/derived_dimension/work.hpp>
//...

#endif // !defined BOOST_UNITS_DERIVED_DIMENSION_HPP

