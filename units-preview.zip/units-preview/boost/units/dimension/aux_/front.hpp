
#if !defined BOOST_UNITS_DIMENSION_AUX_FRONT_HPP_INCLUDED
#  define BOOST_UNITS_DIMENSION_AUX_FRONT_HPP_INCLUDED


#include <boost/mpl/front_fwd.hpp>
#include <boost/mpl/aux_/nttp_decl.hpp>
#include <boost/mpl/aux_/config/typeof.hpp>
#include <boost/mpl/aux_/config/ctps.hpp>

#include <boost/units/dimension/aux_/at.hpp>
#include <boost/units/dimension/aux_/tag.hpp>

namespace boost {
  namespace mpl {

#if defined(BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES)

template<>
struct front_impl< aux::dimension_tag >
{
    template< typename Dimension > struct apply
        : d_at<Dimension,0>
    {
    };
};

#else

#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)

template< BOOST_MPL_AUX_NTTP_DECL(long, n_) >
struct front_impl< aux::dimension_tag<n_> >
{
    template< typename Dimension > struct apply
    {
        typedef typename Dimension::item0 type;
    };
};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

#endif // BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES

}}

#endif // !defined BOOST_UNITS_DIMENSION_AUX_FRONT_HPP_INCLUDED
