
#if !defined BOOST_UNITS_DIMENSION_AUX_O1_SIZE_HPP_INCLUDED
#  define BOOST_UNITS_DIMENSION_AUX_O1_SIZE_HPP_INCLUDED


#include <boost/mpl/O1_size_fwd.hpp>
#include <boost/mpl/minus.hpp>
#include <boost/mpl/long.hpp>
#include <boost/mpl/aux_/config/typeof.hpp>
#include <boost/mpl/aux_/config/ctps.hpp>

#include <boost/units/dimension/aux_/tag.hpp>

namespace boost {
  namespace mpl {

#if defined(BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES)

template<>
struct O1_size_impl< aux::dimension_tag >
{
    template< typename Dimension > struct apply
        : Dimension::size
    {
    };
};

#else

#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)

template< long N >
struct O1_size_impl< aux::dimension_tag<N> >
{
    template< typename Dimension > struct apply
        : mpl::long_<N>
    {
    };
};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

#endif // BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES

}}

#endif // !defined BOOST_UNITS_DIMENSION_AUX_O1_SIZE_HPP_INCLUDED
