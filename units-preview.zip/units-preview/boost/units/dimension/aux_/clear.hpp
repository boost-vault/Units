
#if !defined BOOST_UNITS_DIMENSION_AUX_CLEAR_HPP_INCLUDED
#  define BOOST_UNITS_DIMENSION_AUX_CLEAR_HPP_INCLUDED


#include <boost/mpl/clear_fwd.hpp>
#include <boost/mpl/aux_/config/typeof.hpp>
#include <boost/mpl/aux_/config/ctps.hpp>

#include <boost/units/dimension/aux_/dimension0.hpp>
#include <boost/units/dimension/aux_/tag.hpp>

namespace boost {
  namespace mpl {

#if defined(BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES)

template<>
struct clear_impl< aux::dimension_tag >
{
    template< typename Dimension > struct apply
    {
        typedef dimension0<> type;
    };
};

#else

#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)

template< long N >
struct clear_impl< aux::dimension_tag<N> >
{
    template< typename Dimension > struct apply
    {
        typedef dimension0<> type;
    };
};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

#endif // BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES

}}

#endif // !defined BOOST_UNITS_DIMENSION_AUX_CLEAR_HPP_INCLUDED
