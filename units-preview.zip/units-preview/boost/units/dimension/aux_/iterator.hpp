
#if !defined BOOST_UNITS_DIMENSION_AUX_ITERATOR_HPP_INCLUDED
#  define BOOST_UNITS_DIMENSION_AUX_ITERATOR_HPP_INCLUDED


#include <boost/mpl/iterator_tags.hpp>
#include <boost/mpl/plus.hpp>
#include <boost/mpl/minus.hpp>
#include <boost/mpl/advance_fwd.hpp>
#include <boost/mpl/distance_fwd.hpp>
#include <boost/mpl/next.hpp>
#include <boost/mpl/prior.hpp>
#include <boost/mpl/aux_/nttp_decl.hpp>
#include <boost/mpl/aux_/value_wknd.hpp>
#include <boost/mpl/aux_/config/ctps.hpp>
#include <boost/mpl/aux_/config/workaround.hpp>

#include <boost/units/dimension/aux_/at.hpp>

namespace boost {
  namespace mpl {

template<
      typename Dimension
    , BOOST_MPL_AUX_NTTP_DECL(long, n_)
    >
struct d_iter
{
    typedef aux::d_iter_tag tag;
    typedef random_access_iterator_tag category;
    typedef typename d_at<Dimension,n_>::type type;

    typedef Dimension dimension_;
    typedef mpl::long_<n_> pos;

#if defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)
    enum { 
          next_ = n_ + 1
        , prior_ = n_ - 1
        , pos_ = n_
    };
    
    typedef d_iter<Dimension,next_> next;
    typedef d_iter<Dimension,prior_> prior;
#endif

};


#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)

template<
      typename Dimension
    , BOOST_MPL_AUX_NTTP_DECL(long, n_)
    >
struct next< d_iter<Dimension,n_> >
{
    typedef d_iter<Dimension,(n_ + 1)> type;
};

template<
      typename Dimension
    , BOOST_MPL_AUX_NTTP_DECL(long, n_)
    >
struct prior< d_iter<Dimension,n_> >
{
    typedef d_iter<Dimension,(n_ - 1)> type;
};

template<
      typename Dimension
    , BOOST_MPL_AUX_NTTP_DECL(long, n_)
    , typename Distance
    >
struct advance< d_iter<Dimension,n_>,Distance>
{
    typedef d_iter<
          Dimension
        , (n_ + BOOST_MPL_AUX_NESTED_VALUE_WKND(long, Distance))
        > type;
};

template< 
      typename Dimension
    , BOOST_MPL_AUX_NTTP_DECL(long, n_)
    , BOOST_MPL_AUX_NTTP_DECL(long, m_)
    > 
struct distance< d_iter<Dimension,n_>, d_iter<Dimension,m_> >
    : mpl::long_<(m_ - n_)>
{
};

#else // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

template<> struct advance_impl<aux::d_iter_tag>
{
    template< typename Iterator, typename N > struct apply
    {
        enum { pos_ = Iterator::pos_, n_ = N::value };
        typedef d_iter<
              typename Iterator::dimension_
            , (pos_ + n_)
            > type;
    };
};

template<> struct distance_impl<aux::d_iter_tag>
{
    template< typename Iter1, typename Iter2 > struct apply
    {
        enum { pos1_ = Iter1::pos_, pos2_ = Iter2::pos_ };
        typedef long_<( pos2_ - pos1_ )> type;
        BOOST_STATIC_CONSTANT(long, value = ( pos2_ - pos1_ ));
    };
};

#endif

}}

#endif // !defined BOOST_UNITS_DIMENSION_AUX_ITERATOR_HPP_INCLUDED
