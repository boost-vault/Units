
#if !defined BOOST_UNITS_DIMENSION_AUX_POP_FRONT_HPP_INCLUDED
#  define BOOST_UNITS_DIMENSION_AUX_POP_FRONT_HPP_INCLUDED


#include <boost/mpl/pop_front_fwd.hpp>
#include <boost/mpl/aux_/config/typeof.hpp>

#if defined(BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES)

#   include <boost/units/dimension/aux_/item.hpp>
#   include <boost/units/dimension/aux_/tag.hpp>

namespace boost {
  namespace mpl {

template<>
struct pop_front_impl< aux::dimension_tag >
{
    template< typename Dimension > struct apply
    {
        typedef d_mask<Dimension,1> type;
    };
};

}}

#endif // BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES

#endif // !defined BOOST_UNITS_DIMENSION_AUX_POP_FRONT_HPP_INCLUDED
