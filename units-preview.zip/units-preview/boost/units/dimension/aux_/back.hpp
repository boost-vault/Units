
#if !defined BOOST_UNITS_DIMENSION_AUX_BACK_HPP_INCLUDED
#  define BOOST_UNITS_DIMENSION_AUX_BACK_HPP_INCLUDED


#include <boost/mpl/back_fwd.hpp>
#include <boost/mpl/next_prior.hpp>
#include <boost/mpl/aux_/config/typeof.hpp>
#include <boost/mpl/aux_/config/ctps.hpp>

#include <boost/units/dimension/aux_/at.hpp>
#include <boost/units/dimension/aux_/tag.hpp>

namespace boost {
  namespace mpl {

#if defined(BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES)

template<>
struct back_impl< aux::dimension_tag >
{
    template< typename Dimension > struct apply
        : d_at<
              Dimension
            , prior<typename Dimension::size>::type::value
            >
    {
    };
};

#else

#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)

template< long n_ >
struct back_impl< aux::dimension_tag<n_> >
{
    template< typename Dimension > struct apply
    {
        typedef typename Dimension::back type;
    };
};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

#endif // BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES

}}

#endif // !defined BOOST_UNITS_DIMENSION_AUX_BACK_HPP_INCLUDED
