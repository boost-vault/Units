
#if !defined BOOST_UNITS_DIMENSION_AUX_EMPTY_HPP_INCLUDED
#  define BOOST_UNITS_DIMENSION_AUX_EMPTY_HPP_INCLUDED


#include <boost/mpl/empty_fwd.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/aux_/config/typeof.hpp>
#include <boost/mpl/aux_/config/ctps.hpp>
#include <boost/type_traits/is_same.hpp>

#include <boost/units/dimension/aux_/tag.hpp>

namespace boost {
  namespace mpl {

#if defined(BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES)

template<>
struct empty_impl< aux::dimension_tag >
{
    template< typename Dimension > struct apply
        : is_same<
              typename Dimension::lower_bound_
            , typename Dimension::upper_bound_
            >
    {
    };
};

#else

template<>
struct empty_impl< aux::dimension_tag<0> >
{
    template< typename Dimension > struct apply
        : true_
    {
    };
};

#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)

template< long N >
struct empty_impl< aux::dimension_tag<N> >
{
    template< typename Dimension > struct apply
        : false_
    {
    };
};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

#endif // BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES

}}

#endif // !defined BOOST_UNITS_DIMENSION_AUX_EMPTY_HPP_INCLUDED
