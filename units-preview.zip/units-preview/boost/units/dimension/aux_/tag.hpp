
#if !defined BOOST_UNITS_DIMENSION_AUX_TAG_HPP_INCLUDED
#  define BOOST_UNITS_DIMENSION_AUX_TAG_HPP_INCLUDED


#include <boost/mpl/aux_/config/typeof.hpp>
#include <boost/mpl/aux_/nttp_decl.hpp>

namespace boost {
  namespace mpl {
    namespace aux {

struct d_iter_tag;

#if defined(BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES)
struct dimension_tag;
#else
template< BOOST_MPL_AUX_NTTP_DECL(long, N) > struct dimension_tag;
#endif

}}}

#endif // !defined BOOST_UNITS_DIMENSION_AUX_TAG_HPP_INCLUDED
