
#if !defined BOOST_UNITS_DIMENSION_AUX_PUSH_BACK_HPP_INCLUDED
#  define BOOST_UNITS_DIMENSION_AUX_PUSH_BACK_HPP_INCLUDED


#include <boost/mpl/push_back_fwd.hpp>
#include <boost/mpl/aux_/config/typeof.hpp>

#if defined(BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES)

#   include <boost/units/dimension/aux_/item.hpp>
#   include <boost/units/dimension/aux_/tag.hpp>

namespace boost {
  namespace mpl {

template<>
struct push_back_impl< aux::dimension_tag >
{
    template< typename Dimension, typename T > struct apply
    {
        typedef d_item<T,Dimension,0> type;
    };
};

}}

#endif 

#endif // !defined BOOST_UNITS_DIMENSION_AUX_PUSH_BACK_HPP_INCLUDED
