
//  Boost Units library dimension/add.hpp header file  ---------------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_DIMENSION_ADD_HPP
#  define BOOST_UNITS_DIMENSION_ADD_HPP

#  include <boost/mpl/at.hpp>
#  include <boost/mpl/copy.hpp>
#  include <boost/mpl/equal_to.hpp>
#  include <boost/mpl/eval_if.hpp>
#  include <boost/mpl/fold.hpp>
#  include <boost/mpl/front.hpp>
#  include <boost/mpl/push_back.hpp>
#  include <boost/mpl/sort.hpp>
#  include <boost/mpl/vector.hpp>

#  include <boost/units/base_dimension/zero.hpp>
#  include <boost/units/dimension.hpp>

namespace boost {
  namespace units {
    namespace detail {

using namespace mpl;

template < class Dim1, class Dim2 >
struct add;

struct add_op {
  template <
    typename Arg1,
    typename Arg2
  > struct apply {
private:
    typedef typename at_c < Arg1, 0 >::type t1;
    typedef typename at_c < Arg1, 1 >::type t2;
    typedef typename at_c < Arg1, 2 >::type t3;
public:
    typedef typename eval_if < equal_to < t2, Arg2 >,
        vector < t1, t2, add < t3, Arg2 > >,
        vector < typename push_back < t1, t3 >::type, Arg2, Arg2 > >::type type;
  };
};

template <
  class Dim1,
  class Dim2
> struct add_impl < Dim1, mpl::aux::dimension_tag,
                    Dim2, mpl::aux::dimension_tag > {
private:
  typedef typename copy < Dim2, back_inserter < Dim1 > >::type d1;
  typedef typename sort < d1 >::type d2;
  typedef typename front < d2 >::type e1;
  typedef typename fold < d2,
      vector3 < dimension<>, e1, typename zero<e1>::type >,
      add_op >::type d3;
  typedef typename at_c < d3, 0 >::type t1;
  typedef typename at_c < d3, 2 >::type t3;
public:
  typedef typename push_back < t1, t3 >::type type;
};

    } // namespace detail
  } // namespace units
} // namespace boost

#endif // !defined BOOST_UNITS_DIMENSION_ADD_HPP

