
//  Boost Units library length_unit.hpp header file  -----------------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_LENGTH_UNIT_HPP
#  define BOOST_UNITS_LENGTH_UNIT_HPP

#  include <boost/units/length/foot.hpp>
#  include <boost/units/length/inch.hpp>
#  include <boost/units/length/meter.hpp>
#  include <boost/units/length/mile.hpp>
#  include <boost/units/length/yard.hpp>
//...

#endif // !defined BOOST_UNITS_LENGTH_UNIT_HPP

