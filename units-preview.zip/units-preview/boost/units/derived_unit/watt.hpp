
//  Boost Units library derived_unit/watt.hpp header file  -----------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_DERIVED_UNIT_WATT_HPP
#  define BOOST_UNITS_DERIVED_UNIT_WATT_HPP

#  include <boost/units/length/meter.hpp>
#  include <boost/units/mass/kilogram.hpp>
#  include <boost/units/time/second.hpp>
#  include <boost/units/unit.hpp>

namespace boost {
  namespace units {

typedef unit < meter<2>, kilogram<>, second<-3> > watt;

  } // namespace units
} // namespace boost

#endif // !defined BOOST_UNITS_DERIVED_UNIT_WATT_HPP

