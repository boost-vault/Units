
//  Boost Units library quantity.hpp header file  --------------------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_QUANTITY_HPP
#  define BOOST_UNITS_QUANTITY_HPP

#  include <boost/mpl/assert.hpp>
#  include <boost/mpl/equal.hpp>
#  include <boost/type_traits/is_arithmetic.hpp>
#  include <boost/units/base_dimension/equal.hpp>
#  include <boost/units/config.hpp>
#  include <boost/units/detail/add.hpp>
//#  include <boost/units/detail/subtract.hpp>
#  include <boost/units/measure_fwd.hpp>

namespace boost {
  namespace units {

//  quantity class declaration  --------------------------------------//

template <
  class DimensionType,
  typename ValueType = BOOST_UNITS_DEFAULT_VALUE_TYPE
> class quantity {
  BOOST_MPL_ASSERT ((boost::is_arithmetic < ValueType >));

public:
  typedef DimensionType dimension_type;
  typedef ValueType value_type;

  quantity ();
  quantity (const quantity&);
  quantity& operator= (const quantity&);

  bool operator< (const quantity&) const;
  bool operator== (const quantity&) const;

  quantity operator+ () const;
  quantity operator- () const;
  quantity operator* (const value_type&) const;
  quantity operator/ (const value_type&) const;
  value_type operator/ (const quantity&) const;
  quantity operator+ (const quantity&) const;
  quantity operator- (const quantity&) const;

  quantity& operator*= (const value_type&);
  quantity& operator/= (const value_type&);
  quantity& operator+= (const quantity&);
  quantity& operator-= (const quantity&);

  // extra-dimensional

  template < class DimensionType2 >
  quantity (const quantity < DimensionType2, ValueType >&);

  template < class DimensionType2 >
  quantity< typename detail::add < DimensionType, DimensionType2 >::type,
            ValueType >
  operator* (const quantity < DimensionType2, ValueType >&) const;

protected:
  ValueType value_;

  quantity (const value_type&);

  template < class D, typename V > friend class quantity;
  template < class U, typename V > friend class measure;
}; // class quantity

template < class D, typename V >
inline
quantity < D, V >::quantity () {
  // empty
}

template < class D, typename V >
inline
quantity < D, V >::quantity (const quantity& q) :
  value_ (q.value_) {
  // empty
}

template < class D, typename V >
inline quantity < D, V >&
quantity < D, V >::operator= (const quantity& rhs) {
  value_ = rhs.value_;
  return *this;
}

template < class D1, typename V >
template < class D2 >
inline
quantity < D1, V >::quantity (const quantity < D2, V >& rhs) :
  value_ (rhs.value_) {
  using namespace boost::mpl::placeholders;
  BOOST_MPL_ASSERT (( mpl::equal < D1, D2, detail::equal<_1, _2> > ));
}

template < class D, typename V >
inline
quantity < D, V >::quantity (const value_type& v) :
  value_ (v) {
  // empty
}

template < class D, typename V >
inline quantity< D, V >
quantity< D, V >::operator+ () const {
  return quantity (value_);
}

template < class D, typename V >
inline quantity< D, V >
quantity< D, V >::operator- () const {
  return quantity (-value_);
}

template < class D, typename V >
inline quantity< D, V >
quantity< D, V >::operator* (const value_type& value) const {
  return quantity (value_ * value);
}

template < class D, typename V >
inline quantity< D, V >
quantity< D, V >::operator/ (const value_type& value) const {
  return quantity (value_ / value);
}

template < class D, typename V >
inline typename quantity< D, V >::value_type
quantity< D, V >::operator/ (const quantity& q) const {
  return value_ / q.value_;
}

template < class D, typename V >
inline quantity< D, V >
quantity< D, V >::operator+ (const quantity& q) const {
  return quantity (value_ + q.value_);
}

template < class D, typename V >
inline quantity< D, V >
quantity< D, V >::operator- (const quantity& q) const {
  return quantity (value_ - q.value_);
}

template < class D, typename V >
inline bool
quantity< D, V >::operator< (const quantity& q) const {
  return value_ < q.value_;
}

template < class D, typename V >
inline bool
quantity< D, V >::operator== (const quantity& q) const {
  return value_ == q.value_;
}

template < class D, typename V >
inline quantity< D, V >&
quantity< D, V >::operator*= (const value_type& value) {
  return (*this = *this * value);
}

template < class D, typename V >
inline quantity< D, V >&
quantity< D, V >::operator/= (const value_type& value) {
  return (*this = *this / value);
}

template < class D, typename V >
inline quantity< D, V >&
quantity < D, V >::operator+= (const quantity& q) {
  return (*this = *this + q);
}

template < class D, typename V >
inline quantity< D, V >&
quantity< D, V >::operator-= (const quantity& q) {
  return (*this = *this - q);
}

template < class D1, typename V >
template < class D2 >
inline quantity< typename detail::add < D1, D2 >::type, V >
quantity< D1, V >::operator* (const quantity< D2, V >& rhs) const {
  return value_ * rhs.value_;
}

  } // namespace units
} // namespace boost

#endif // !defined BOOST_UNITS_QUANTITY_HPP

