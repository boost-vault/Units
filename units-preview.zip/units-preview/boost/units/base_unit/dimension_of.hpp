
//  Boost Units library base_unit/dimension_of.hpp header file  ------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_BASE_UNIT_DIMENSION_OF_HPP
#  define BOOST_UNITS_BASE_UNIT_DIMENSION_OF_HPP

#  include <boost/units/detail/base_unit.hpp>

namespace boost {
  namespace units {
    namespace detail {

template < class UnitType, class UnitTag >
struct dimension_of_impl;

template < class UnitType >
struct dimension_of_impl < UnitType, base_unit_tag > {
  typedef typename UnitType::dimension type;
};

    } // namespace detail
  } // namespace units
} // namespace boost

#endif // !defined BOOST_UNITS_BASE_UNIT_DIMENSION_OF_HPP

