
//  Boost Units library base_unit/value_of.hpp header file  ----------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_BASE_UNIT_VALUE_OF_HPP
#  define BOOST_UNITS_BASE_UNIT_VALUE_OF_HPP

#  include <boost/mpl/equal_to.hpp>
#  include <boost/mpl/greater.hpp>
#  include <boost/mpl/if.hpp>
#  include <boost/units/base_unit/tag.hpp>

#  if defined(BOOST_HAS_LONG_LONG)
#    include <boost/mpl/integral_c.hpp>
#    define LONG_LONG(N) mpl::integral_c<long long, N>
#  else
#    include <boost/mpl/long.hpp>
#    define LONG_LONG(N) mpl::long_<N>
#  endif // defined(BOOST_HAS_LONG_LONG)

namespace boost {
  namespace units {
    namespace detail {

// value_of < BaseUnitType > provides a ValueType conversion operator that
// returns the scale of BaseUnit if its exponent is positive or the inverse
// scale if its exponent is negative.

template < class BaseUnitType, class BaseUnitTag, typename ValueType  >
struct value_of_impl;

template <
  class BaseUnitType,
  typename ValueType
> struct value_of_impl < BaseUnitType, detail::base_unit_tag, ValueType > {
private:
  typedef typename BaseUnitType::exponent exp;
  typedef typename mpl::equal_to < exp, LONG_LONG(0LL) >::type eq;
  typedef typename mpl::greater < exp, LONG_LONG(0LL) >::type gr;
public:
  typedef typename mpl::if_ < eq, LONG_LONG(1LL),
      mpl::if_ < gr, typename BaseUnitType::numer,
          typename BaseUnitType::denom > >::type numer;
  typedef typename mpl::if_ < eq, LONG_LONG(1LL),
      mpl::if_ < gr, typename BaseUnitType::denom,
          typename BaseUnitType::numer > >::type denom;

  operator ValueType() const {
    return ValueType(numer::type::value) / ValueType(denom::type::value);
  }
};

    } // namespace detail
  } // namespace units
} // namespace boost

#endif // !defined BOOST_UNITS_BASE_UNIT_VALUE_OF_HPP

