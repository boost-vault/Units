
//  Boost Units library detail/base_dimension.hpp header file  -------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_DETAIL_BASE_DIMENSION_HPP
#  define BOOST_UNITS_DETAIL_BASE_DIMENSION_HPP

#  include <boost/mpl/int.hpp>
#  include <boost/mpl/integral_c.hpp>

// NOTE: Structure member 'exponent' may only need be defined as
// BOOST_STATIC_CONSTANT.
//
// NOTE: Structure member 'tag2' is just a tag but it is not named 'tag'
// because metafunctions of the base class depends on the 'tag' member.
//
#  define BOOST_UNITS_DETAIL_BASE_DIMENSION(Name, Rank) \
struct Name##_tag { }; \
template < int Exponent = 1 > \
struct Name : \
  mpl::integral_c < unsigned, Rank > { \
  typedef Name type; \
  typedef Name##_tag tag2; \
  typedef mpl::int_ < Exponent> exponent; \
};

#endif // !defined BOOST_UNITS_DETAIL_BASE_DIMENSION_HPP

