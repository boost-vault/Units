
//  Boost Units library detail/base_unit.hpp header file  ------------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_DETAIL_BASE_UNIT_HPP
#  define BOOST_UNITS_DETAIL_BASE_UNIT_HPP

#  include <boost/mpl/long.hpp>
#  include <boost/units/base_unit/tag.hpp>

#  define BOOST_UNITS_DETAIL_BASE_UNIT(Name, Base, Numer, Denom) \
struct Name##_tag {}; \
template < \
  int Exponent = 1 \
> struct Name : \
  Base < Exponent > { \
  typedef Name type; \
  typedef detail::base_unit_tag tag2; \
  typedef Base < Exponent > dimension; \
  typedef Name##_tag unit; \
  typedef mpl::long_<Numer> numer; \
  typedef mpl::long_<Denom> denom; \
}; \
/**/

#endif // !defined BOOST_UNITS_DETAIL_BASE_UNIT_HPP

