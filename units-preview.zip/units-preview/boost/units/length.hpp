
//  Boost Units library length.hpp header file  ----------------------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_LENGTH_HPP
#  define BOOST_UNITS_LENGTH_HPP

#  include <boost/units/detail/base_dimension.hpp>

namespace boost {
  namespace units {

BOOST_UNITS_DETAIL_BASE_DIMENSION (length, 0)

  } // namespace units
} // namespace boost

#endif // !defined BOOST_UNITS_LENGTH_HPP

