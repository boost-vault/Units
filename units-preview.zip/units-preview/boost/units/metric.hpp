
//  Boost Units library metric.hpp header file  ----------------------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_METRIC_HPP
#  define BOOST_UNITS_METRIC_HPP

// TODO: Seperate these into individual header files.
//#  include <boost/units/metric/kilo.hpp>
//...

#  include <boost/units/detail/metric.hpp>

namespace boost {
  namespace units {

//BOOST_UNITS_DETAIL_METRIC_UNIT(yotta, 1e24) // Greek or Latin octo, "eight"
//BOOST_UNITS_DETAIL_METRIC_UNIT(zetta, 1e21) // Latin septem, "seven"
//BOOST_UNITS_DETAIL_METRIC_UNIT(exa, 1e18) // Greek hex, "six"
//BOOST_UNITS_DETAIL_METRIC_UNIT(peta, 1e15) // Greek pente, "five"
//BOOST_UNITS_DETAIL_METRIC_UNIT(tera, 1e12) // Greek teras, "monster"
BOOST_UNITS_DETAIL_METRIC_UNIT(giga, 1000000000, 1) // Greek gigas, "giant"
BOOST_UNITS_DETAIL_METRIC_UNIT(mega, 1000000, 1) // Greek megas, "large"
BOOST_UNITS_DETAIL_METRIC_UNIT(myria, 10000, 1) // Not an official SI prefix
BOOST_UNITS_DETAIL_METRIC_UNIT(kilo, 1000, 1) // Greek chilioi, "thousand"
BOOST_UNITS_DETAIL_METRIC_UNIT(hecto, 100, 1) // Greek hekaton, "hundred"
BOOST_UNITS_DETAIL_METRIC_UNIT(deca, 10, 1) // Greek deka, "ten"
BOOST_UNITS_DETAIL_METRIC_UNIT(deka, 10, 1)
BOOST_UNITS_DETAIL_METRIC_UNIT(deci, 1, 10) // Latin decimus, "tenth"
BOOST_UNITS_DETAIL_METRIC_UNIT(centi, 1, 100) // Latin centum, "hundred"
BOOST_UNITS_DETAIL_METRIC_UNIT(milli, 1, 1000) // Latin mille, "thousand"
BOOST_UNITS_DETAIL_METRIC_UNIT(micro, 1, 1000000) // Latin micro or Greek mikros, "small"
BOOST_UNITS_DETAIL_METRIC_UNIT(nano, 1, 1000000000) // Latin nanus or Greek nanos, "dwarf"
//BOOST_UNITS_DETAIL_METRIC_UNIT(pico,  1e-12) // Spanish pico, "a bit"
//BOOST_UNITS_DETAIL_METRIC_UNIT(femto, 1e-15) // Danish-Norwegian femten, "fifteen"
//BOOST_UNITS_DETAIL_METRIC_UNIT(atto,  1e-18) // Danish-Norwegian atten, "eighteen"
//BOOST_UNITS_DETAIL_METRIC_UNIT(zepto, 1e-21) // Latin septem, "seven"
//BOOST_UNITS_DETAIL_METRIC_UNIT(yocto, 1e-24) // Greek or Latin octo, "eight"

  } // namespace units
} // namespace boost

#endif // !defined BOOST_UNITS_METRIC_HPP

