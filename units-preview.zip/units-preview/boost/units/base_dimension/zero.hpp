
//  Boost Units library base_dimension/zero.hpp header file  ---------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_BASE_DIMENSION_ZERO_HPP
#  define BOOST_UNITS_BASE_DIMENSION_ZERO_HPP

#  include <boost/units/base_dimension.hpp>

#  define BOOST_UNITS_BASE_DIMENSION_ZERO(Name) \
template < class BaseDim > \
struct zero_impl < BaseDim, Name##_tag > : Name <0> { \
  typedef Name<0> type; \
}; \
/**/

namespace boost {
  namespace units {
    namespace detail {

template < class BaseDim, class BaseDimTag >
struct zero_impl;

BOOST_UNITS_BASE_DIMENSION_ZERO (length)
BOOST_UNITS_BASE_DIMENSION_ZERO (mass)
BOOST_UNITS_BASE_DIMENSION_ZERO (time)
BOOST_UNITS_BASE_DIMENSION_ZERO (temperature)
BOOST_UNITS_BASE_DIMENSION_ZERO (electricity)
BOOST_UNITS_BASE_DIMENSION_ZERO (substance)
BOOST_UNITS_BASE_DIMENSION_ZERO (luminosity)

template < class BaseDim >
struct zero : zero_impl < BaseDim, typename BaseDim::tag2 > { };

    } // namespace detail
  } // namespace units
} // namespace boost

#endif // !defined BOOST_UNITS_BASE_DIMENSION_ZERO_HPP

