
//  Boost Units library base_dimension/add.hpp header file  ----------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_BASE_DIMENSION_ADD_HPP
#  define BOOST_UNITS_BASE_DIMENSION_ADD_HPP

#  include <boost/units/base_dimension.hpp>

#  define BOOST_UNITS_BASE_DIMENSION_ADD(Name) \
template < class BaseDim1, class BaseDim2 > \
struct add_impl < BaseDim1, Name##_tag, BaseDim2, Name##_tag > : \
  Name < BaseDim1::exponent::value + BaseDim2::exponent::value > { \
  typedef Name < BaseDim1::exponent::value + BaseDim2::exponent::value > type; \
}; \
/**/

namespace boost {
  namespace units {
    namespace detail {

template < class BaseDim1, class BaseDimTag1,
           class BaseDim2, class BaseDimTag2 >
struct add_impl;

BOOST_UNITS_BASE_DIMENSION_ADD (length)
BOOST_UNITS_BASE_DIMENSION_ADD (mass)
BOOST_UNITS_BASE_DIMENSION_ADD (time)
BOOST_UNITS_BASE_DIMENSION_ADD (temperature)
BOOST_UNITS_BASE_DIMENSION_ADD (electricity)
BOOST_UNITS_BASE_DIMENSION_ADD (substance)
BOOST_UNITS_BASE_DIMENSION_ADD (luminosity)

    } // namespace detail
  } // namespace units
} // namespace boost

#endif // !defined BOOST_UNITS_BASE_DIMENSION_ADD_HPP

