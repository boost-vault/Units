
//  Boost Units library base_dimension/equal.hpp header file  --------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_BASE_DIMENSION_EQUAL_HPP
#  define BOOST_UNITS_BASE_DIMENSION_EQUAL_HPP

#  include <boost/mpl/bool_fwd.hpp>
#  include <boost/mpl/equal_to.hpp>

#  include <boost/units/base_dimension.hpp>

#  define BOOST_UNITS_BASE_DIMENSION_EQUAL(Name) \
template < class BaseDim1, class BaseDim2 > \
struct equal_impl < BaseDim1, Name##_tag, BaseDim2, Name##_tag > : \
  mpl::equal_to < typename BaseDim1::exponent, \
                  typename BaseDim2::exponent >::type { }; \
/**/

namespace boost {
  namespace units {
    namespace detail {

template < class BaseDim1, class BaseDimTag1,
           class BaseDim2, class BaseDimTag2 >
struct equal_impl : mpl::false_ { };

BOOST_UNITS_BASE_DIMENSION_EQUAL (length)
BOOST_UNITS_BASE_DIMENSION_EQUAL (mass)
BOOST_UNITS_BASE_DIMENSION_EQUAL (time)
BOOST_UNITS_BASE_DIMENSION_EQUAL (electricity)
BOOST_UNITS_BASE_DIMENSION_EQUAL (temperature)
BOOST_UNITS_BASE_DIMENSION_EQUAL (substance)
BOOST_UNITS_BASE_DIMENSION_EQUAL (luminosity)

template < class BaseDim1, class BaseDim2 >
struct equal :
    equal_impl < BaseDim1, typename BaseDim1::tag2,
                 BaseDim2, typename BaseDim2::tag2 > { };

    } // namespace detail
  } // namespace units
} // namespace boost

#endif // !defined BOOST_UNITS_BASE_DIMENSION_EQUAL_HPP

