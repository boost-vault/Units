
//  Boost Units library units/quantity_fwd.hpp header file  ------------------//

//  (C) Copyright Eric Lemings 2004. Permission to copy, use, modify, sell and
//  distribute this software is granted provided this copyright notice appears
//  in all copies. This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  See http://www.boost.org for updates, documentation, and revision history.

#if !defined BOOST_UNITS_QUANTITY_FWD_HPP
#  define BOOST_UNITS_QUANTITY_FWD_HPP

#  include <boost/units/config.hpp>

namespace boost {
  namespace units {

template <
  class DimensionType,
  typename ValueType = BOOST_UNITS_DEFAULT_VALUE_TYPE
> struct quantity;

  } // namespace units
} // namespace boost

#endif // !defined BOOST_UNITS_QUANTITY_FWD_HPP

