
//  Boost Units library dimension.hpp header file  -------------------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_DIMENSION_HPP
#  define BOOST_UNITS_DIMENSION_HPP

#  if !defined(BOOST_MPL_PREPROCESSING_MODE)
#    include <boost/units/config.hpp>
#    include <boost/mpl/aux_/na.hpp>
#    include <boost/mpl/aux_/config/preprocessor.hpp>

#    include <boost/preprocessor/inc.hpp>
#    include <boost/preprocessor/cat.hpp>
#    include <boost/preprocessor/stringize.hpp>

#    if !defined(BOOST_NEEDS_TOKEN_PASTING_OP_FOR_TOKENS_JUXTAPOSING)
#      define AUX778076_UNIT_HEADER \
    BOOST_PP_CAT(dimension, BOOST_UNITS_LIMIT_DIMENSION_SIZE).hpp \
    /**/
#    else
#      define AUX778076_UNIT_HEADER \
    BOOST_PP_CAT(dimension, BOOST_UNITS_LIMIT_DIMENSION_SIZE)##.hpp \
    /**/
#    endif

#   include BOOST_PP_STRINGIZE(boost/units/dimension/AUX778076_UNIT_HEADER)
#   undef AUX778076_UNIT_HEADER
#endif

#  include <boost/units/config.hpp>

#  define AUX778076_SEQUENCE_NAME dimension
#  define AUX778076_SEQUENCE_LIMIT BOOST_UNITS_LIMIT_DIMENSION_SIZE
#  include <boost/mpl/aux_/sequence_wrapper.hpp>

namespace boost {
  namespace units {

using mpl::dimension;

  } // namespace units
} // namespace boost

#endif // !defined BOOST_UNITS_DIMENSION_HPP

