
//  Boost Units library config.hpp header file  ----------------------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_CONFIG_HPP
#  define BOOST_UNITS_CONFIG_HPP

#  include <boost/config.hpp>

#  if !defined BOOST_UNITS_DEFAULT_VALUE_TYPE
#    define BOOST_UNITS_DEFAULT_VALUE_TYPE double
#  endif // !defined BOOST_UNITS_DEFAULT_VALUE_TYPE

#  if !defined(BOOST_UNITS_LIMIT_DIMENSION_SIZE)
#    define BOOST_UNITS_LIMIT_DIMENSION_SIZE 10
#  endif // !defined BOOST_UNITS_LIMIT_DIMENSION_SIZE

#  if !defined(BOOST_UNITS_LIMIT_UNIT_SIZE)
#    define BOOST_UNITS_LIMIT_UNIT_SIZE BOOST_UNITS_LIMIT_DIMENSION_SIZE 
#  endif // !defined BOOST_UNITS_LIMIT_UNIT_SIZE

#endif // !defined BOOST_UNITS_CONFIG_HPP

