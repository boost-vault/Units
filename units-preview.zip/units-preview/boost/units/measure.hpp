
//  Boost Units library measure.hpp header file  ---------------------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_MEASURE_HPP
#  define BOOST_UNITS_MEASURE_HPP

#  include <boost/static_assert.hpp>
#  include <boost/type_traits/is_arithmetic.hpp>
#  include <boost/units/config.hpp>
#  include <boost/units/quantity.hpp>
#  include <boost/units/detail/add.hpp>
#  include <boost/units/detail/convert.hpp>
#  include <boost/units/detail/dimension_of.hpp>
#  include <boost/units/unit.hpp>
#  include <boost/units/unit/same_dimension.hpp>

namespace boost {
  namespace units {

template <
  class UnitType = unit<>,
  typename ValueType = BOOST_UNITS_DEFAULT_VALUE_TYPE
> struct measure :
  quantity < typename detail::dimension_of< UnitType >::type, ValueType > {

  typedef ValueType value_type;
  typedef UnitType unit_type;
  typedef typename detail::dimension_of< UnitType >::type dimension_type;
  typedef quantity < dimension_type, ValueType > quantity_type;

  measure ();
  measure (const measure&);
  measure& operator= (const measure&);
  measure (const value_type&);
  measure& operator= (const value_type&);
  measure (const quantity_type&);
  measure& operator= (const quantity_type&);
  template < class UnitType2 >
  measure (const measure < UnitType2, ValueType >&);
  template < class UnitType2 >
  measure& operator= (const measure < UnitType2, ValueType >&);

  measure operator+ () const;
  measure operator- () const;
  measure operator* (const value_type&) const;
  measure operator/ (const value_type&) const;
  value_type operator/ (const measure&) const;
  measure operator+ (const measure&) const;
  measure operator- (const measure&) const;

  measure& operator*= (const value_type&);
  measure& operator/= (const value_type&);
  measure& operator+= (const measure&);
  measure& operator-= (const measure&);

  template < class UnitType2 >
  quantity < typename detail::add < UnitType, UnitType2 >::type, ValueType >
  operator* (const measure< UnitType2, ValueType >&) const;
  //template < class UnitType2 >
  //quantity < typename detail::subtract < UnitType, UnitType2 >::type, ValueType >
  //operator* (const measure< UnitType2, ValueType >&) const;
  template < class UnitType2 >
  quantity_type operator+ (const measure< UnitType2, ValueType >&) const;
  template < class UnitType2 >
  quantity_type operator- (const measure< UnitType2, ValueType >&) const;

  value_type value() const;
};

template < class U, typename V >
inline
measure< U, V >::measure () {
  // empty
}

template < class U, typename V >
inline
measure< U, V >::measure (const measure& m):
  quantity_type (m) {
  // empty
}

template < class U, typename V >
inline measure < U, V >&
measure< U, V >::operator= (const measure& m) {
  quantity_type::operator= (m);
  return *this;
}

template < class U, typename V >
inline
measure< U, V >::measure (const value_type& v):
  quantity_type (detail::convert<U> (v)) {
  // empty
}

template < class U, typename V >
inline measure < U, V >&
measure< U, V >::operator= (const value_type& v) {
  this->value_ = detail::convert<U> (v);
  return *this;
}

template < class U, typename V >
inline
measure < U, V >::measure (const quantity_type& q) :
  quantity_type (q) {
}

template < class U, typename V >
inline measure < U, V >&
measure< U, V >::operator= (const quantity_type& q) {
  this->value_ = q.value_;
  return *this;
}

template < class U1, typename V >
template < class U2 >
inline
measure < U1, V >::measure (const measure < U2, V >& m) :
  quantity_type (m.value_) {
  BOOST_MPL_ASSERT (( detail::same_dimension < U1, U2 > ));
}

template < class U1, typename V >
template < class U2 >
inline measure < U1, V >&
measure < U1, V >::operator= (const measure < U2, V >& m) {
  BOOST_MPL_ASSERT (( detail::same_dimension < U1, U2 > ));
  this->value_ = m.value_;
  return *this;
}

template < class U, typename V >
inline measure< U, V >
measure< U, V >::operator+ () const {
  return measure (this->value_);
}

template < class U, typename V >
inline measure< U, V >
measure< U, V >::operator- () const {
  return measure (-this->value_);
}

template < class U, typename V >
inline measure< U, V >
measure< U, V >::operator* (const value_type& value) const {
  return measure (this->value_ * value);
}

template < class U, typename V >
inline measure< U, V >
measure< U, V >::operator/ (const value_type& value) const {
  return measure (this->value_ / value);
}

template < class U, typename V >
inline typename measure< U, V >::value_type
measure< U, V >::operator/ (const measure& q) const {
  return this->value_ / q.value_;
}

template < class U, typename V >
inline measure< U, V >
measure< U, V >::operator+ (const measure& q) const {
  return measure (this->value_ + q.value_);
}

template < class U, typename V >
inline measure< U, V >
measure< U, V >::operator- (const measure& q) const {
  return measure (this->value_ - q.value_);
}

template < class U, typename V >
inline measure< U, V >&
measure< U, V >::operator*= (const value_type& value) {
  return (*this = *this * value);
}

template < class U, typename V >
inline measure< U, V >&
measure< U, V >::operator/= (const value_type& value) {
  return (*this = *this / value);
}

template < class U, typename V >
inline measure< U, V >&
measure < U, V >::operator+= (const measure& q) {
  return (*this = *this + q);
}

template < class U, typename V >
inline measure< U, V >&
measure< U, V >::operator-= (const measure& q) {
  return (*this = *this - q);
}

template < class U1, typename V >
template < class U2 >
inline quantity< typename detail::add < U1, U2 >::type, V >
measure< U1, V >::operator* (const measure< U2, V >& rhs) const {
  return this->value_ * rhs.value_;
}

template < class U1, typename V >
template < class U2 >
inline typename measure < U1, V >::quantity_type
measure< U1, V >::operator+ (const measure< U2, V >& rhs) const {
  BOOST_MPL_ASSERT (( detail::same_dimension < U1, U2 > ));
  return this->value_ + rhs.value_;
}

template < class U1, typename V >
template < class U2 >
inline typename measure < U1, V >::quantity_type
measure< U1, V >::operator- (const measure< U2, V >& rhs) const {
  BOOST_MPL_ASSERT (( detail::same_dimension < U1, U2 > ));
  return this->value_ - rhs.value_;
}

template < class U, typename V >
inline typename measure< U, V >::value_type
measure< U, V >::value () const {
  return this->value_ / detail::convert < U, V > (1);
}

  } // namespace units
} // namespace boost

#endif // !defined BOOST_UNITS_MEASURE_HPP

