
//  Boost Units library unit/add.hpp header file  --------------------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_UNIT_ADD_HPP
#  define BOOST_UNITS_UNIT_ADD_HPP

#  include <boost/units/dimension/add.hpp>
#  include <boost/units/unit/aux_/tag.hpp>
#  include <boost/units/unit/dimension_of.hpp>

namespace boost {
  namespace units {
    namespace detail {

template < class Unit1, class Unit2 >
struct add;

template <
  class Unit1,
  class Unit2
> struct add_impl < Unit1, mpl::aux::unit_tag,
                    Unit2, mpl::aux::unit_tag > {
private:
  typedef typename dimension_of < Unit1 >::type d1;
  typedef typename dimension_of < Unit2 >::type d2;
public:
  typedef typename add < d1, d2 >::type type;
};

    } // namespace detail
  } // namespace units
} // namespace boost

#endif // !defined BOOST_UNITS_UNIT_ADD_HPP

