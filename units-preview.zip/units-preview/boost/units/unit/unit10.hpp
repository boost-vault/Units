
#ifndef BOOST_UNITS_UNIT_UNIT10_HPP_INCLUDED
#  define BOOST_UNITS_UNIT_UNIT10_HPP_INCLUDED


#if !defined(BOOST_MPL_PREPROCESSING_MODE)
#   include <boost/units/unit/unit0.hpp>
#endif

//#include <boost/mpl/aux_/config/use_preprocessed.hpp>
#define BOOST_MPL_CFG_NO_PREPROCESSED_HEADERS

#if !defined(BOOST_MPL_CFG_NO_PREPROCESSED_HEADERS) \
    && !defined(BOOST_MPL_PREPROCESSING_MODE)

#   define BOOST_MPL_PREPROCESSED_HEADER unit10.hpp
#   include <boost/units/unit/aux_/include_preprocessed.hpp>

#else

#   include <boost/mpl/aux_/config/typeof.hpp>
#   include <boost/mpl/aux_/config/ctps.hpp>
#   include <boost/preprocessor/iterate.hpp>

namespace boost {
  namespace mpl {

#   define BOOST_PP_ITERATION_PARAMS_1 \
    (3,(0, 10, <boost/units/unit/aux_/numbered.hpp>))
#   include BOOST_PP_ITERATE()

}}

#endif // BOOST_MPL_CFG_NO_PREPROCESSED_HEADERS

#endif // !defined BOOST_UNITS_UNIT_UNIT10_HPP_INCLUDED
