
//  Boost Units library unit/dimension_of.hpp header file  -----------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_UNIT_DIMENSION_OF_HPP
#  define BOOST_UNITS_UNIT_DIMENSION_OF_HPP

#  include <boost/mpl/transform.hpp>
#  include <boost/mpl/inserter.hpp>
#  include <boost/mpl/push_back.hpp>
#  include <boost/mpl/placeholders.hpp>

#  include <boost/units/base_unit/dimension_of.hpp>
#  include <boost/units/dimension.hpp>
#  include <boost/units/unit/aux_/tag.hpp>

namespace boost {
  namespace units {
    namespace detail {

template < class BaseUnitType >
struct dimension_of;

struct dimension_of_op {
  template < class BaseUnitType >
  struct apply {
    typedef typename dimension_of < BaseUnitType >::type type;
  };
};

using namespace mpl::placeholders;

template < class UnitType, class UnitTag  >
struct dimension_of_impl;

template < class UnitType >
struct dimension_of_impl < UnitType, mpl::aux::unit_tag > {
  //BOOST_MPL_ASSERT (( is_sequence < UnitType > ));
  typedef typename mpl::transform < UnitType, dimension_of_op,
      mpl::inserter < dimension<>, mpl::push_back < _1, _2 > >
   >::type type;
};

    } // namespace detail
  } // namespace units
} // namespace boost

#endif // !defined BOOST_UNITS_UNIT_DIMENSION_OF_HPP

