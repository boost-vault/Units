
//  Boost Units library unit/value_of.hpp header file  ---------------//

//  Copyright (c) 2005, 2006 Eric Lemings

//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org for updates, documentation, and revision
//  history.

#if !defined BOOST_UNITS_UNIT_VALUE_OF_HPP
#  define BOOST_UNITS_UNIT_VALUE_OF_HPP

#  include <boost/mpl/accumulate.hpp>
#  include <boost/mpl/pair.hpp>
#  include <boost/mpl/times.hpp>
#  include <boost/units/config.hpp>
#  include <boost/units/base_unit/value_of.hpp>
#  include <boost/units/detail/value_of_fwd.hpp>
#  include <boost/units/detail/reduce.hpp>
#  include <boost/units/unit/aux_/tag.hpp>

#  if defined(BOOST_HAS_LONG_LONG)
#    include <boost/mpl/integral_c.hpp>
#    define LONG_LONG(N) mpl::integral_c<long long, N>
#  else
#    include <boost/mpl/long.hpp>
#    define LONG_LONG(N) mpl::long_<N>
#  endif // defined(BOOST_HAS_LONG_LONG)

namespace boost {
  namespace units {
    namespace detail {

using namespace boost::mpl;

struct value_of_op {
  template < class Ratio, class BaseUnit >
  struct apply {
  private:
    typedef typename first < Ratio >::type n1;
    typedef typename value_of < BaseUnit >::numer::type n2;
    typedef typename times< n1, n2 >::type n3;
    typedef typename second < Ratio >::type d1;
    typedef typename value_of < BaseUnit >::denom::type d2;
    typedef typename times< d1, d2 >::type d3;
#  if defined(BOOST_HAS_LONG_LONG)
    typedef reduce < long long, n3::type::value, d3::type::value > r;
#  else
    typedef reduce < long, n3::type::value, d3::type::value > r;
#  endif // defined(BOOST_HAS_LONG_LONG)
  public:
    typedef pair < LONG_LONG(r::numer), LONG_LONG(r::denom) > type;
  };
};

template < class UnitType, typename ValueType >
struct value_of_impl < UnitType, mpl::aux::unit_tag, ValueType > {
private:
  typedef typename accumulate < UnitType,
      pair < LONG_LONG(1LL), LONG_LONG(1LL) >,
      value_of_op >::type ratio;
public:
  typedef typename first < ratio >::type numer;
  typedef typename second < ratio >::type denom;

  operator ValueType() const {
    return ValueType(numer::type::value) / ValueType(denom::type::value);
  }
};

    } // namespace detail
  } // namespace units
} // namespace boost

#endif // !defined BOOST_UNITS_UNIT_VALUE_OF_HPP

