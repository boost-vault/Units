
#if !defined BOOST_UNITS_UNIT_AUX_FRONT_HPP_INCLUDED
#  define BOOST_UNITS_UNIT_AUX_FRONT_HPP_INCLUDED


#include <boost/mpl/front_fwd.hpp>
#include <boost/mpl/aux_/nttp_decl.hpp>
#include <boost/mpl/aux_/config/typeof.hpp>
#include <boost/mpl/aux_/config/ctps.hpp>

#include <boost/units/unit/aux_/at.hpp>
#include <boost/units/unit/aux_/tag.hpp>

namespace boost {
  namespace mpl {

#if defined(BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES)

template<>
struct front_impl< aux::unit_tag >
{
    template< typename Unit > struct apply
        : u_at<Unit,0>
    {
    };
};

#else

#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)

template< BOOST_MPL_AUX_NTTP_DECL(long, n_) >
struct front_impl< aux::unit_tag<n_> >
{
    template< typename Unit > struct apply
    {
        typedef typename Unit::item0 type;
    };
};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

#endif // BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES

}}

#endif // !defined BOOST_UNITS_UNIT_AUX_FRONT_HPP_INCLUDED
