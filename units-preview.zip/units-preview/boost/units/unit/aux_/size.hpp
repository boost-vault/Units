
#if !defined BOOST_UNITS_UNIT_AUX_SIZE_HPP_INCLUDED
#  define BOOST_UNITS_UNIT_AUX_SIZE_HPP_INCLUDED


#include <boost/mpl/size_fwd.hpp>
#include <boost/mpl/aux_/config/typeof.hpp>
#include <boost/mpl/aux_/config/ctps.hpp>

#include <boost/units/unit/aux_/O1_size.hpp>
#include <boost/units/unit/aux_/tag.hpp>

namespace boost {
  namespace mpl {

#if defined(BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES)

template<>
struct size_impl< aux::unit_tag >
    : O1_size_impl< aux::unit_tag >
{
};

#else

#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)

template< long N >
struct size_impl< aux::unit_tag<N> >
    : O1_size_impl< aux::unit_tag<N> >
{
};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

#endif // BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES

}}

#endif // !defined BOOST_UNITS_UNIT_AUX_SIZE_HPP_INCLUDED
