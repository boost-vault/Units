
#if !defined BOOST_UNITS_UNIT_AUX_EMPTY_HPP_INCLUDED
#  define BOOST_UNITS_UNIT_AUX_EMPTY_HPP_INCLUDED


#include <boost/mpl/empty_fwd.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/aux_/config/typeof.hpp>
#include <boost/mpl/aux_/config/ctps.hpp>
#include <boost/type_traits/is_same.hpp>

#include <boost/units/unit/aux_/tag.hpp>

namespace boost {
  namespace mpl {

#if defined(BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES)

template<>
struct empty_impl< aux::unit_tag >
{
    template< typename Unit > struct apply
        : is_same<
              typename Unit::lower_bound_
            , typename Unit::upper_bound_
            >
    {
    };
};

#else

template<>
struct empty_impl< aux::unit_tag<0> >
{
    template< typename Unit > struct apply
        : true_
    {
    };
};

#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)

template< long N >
struct empty_impl< aux::unit_tag<N> >
{
    template< typename Unit > struct apply
        : false_
    {
    };
};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

#endif // BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES

}}

#endif // !defined BOOST_UNITS_UNIT_AUX_EMPTY_HPP_INCLUDED
