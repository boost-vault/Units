
#if !defined BOOST_UNITS_UNIT_AUX_BACK_HPP_INCLUDED
#  define BOOST_UNITS_UNIT_AUX_BACK_HPP_INCLUDED


#include <boost/mpl/back_fwd.hpp>
#include <boost/mpl/next_prior.hpp>
#include <boost/mpl/aux_/config/typeof.hpp>
#include <boost/mpl/aux_/config/ctps.hpp>

#include <boost/units/unit/aux_/at.hpp>
#include <boost/units/unit/aux_/tag.hpp>

namespace boost {
  namespace mpl {

#if defined(BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES)

template<>
struct back_impl< aux::unit_tag >
{
    template< typename Unit > struct apply
        : u_at<
              Unit
            , prior<typename Unit::size>::type::value
            >
    {
    };
};

#else

#if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION)

template< long n_ >
struct back_impl< aux::unit_tag<n_> >
{
    template< typename Unit > struct apply
    {
        typedef typename Unit::back type;
    };
};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

#endif // BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES

}}

#endif // !defined BOOST_UNITS_UNIT_AUX_BACK_HPP_INCLUDED
