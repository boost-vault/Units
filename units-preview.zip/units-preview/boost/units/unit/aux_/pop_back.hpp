
#if !defined BOOST_UNITS_UNIT_AUX_POP_BACK_HPP_INCLUDED
#  define BOOST_UNITS_UNIT_AUX_POP_BACK_HPP_INCLUDED


#include <boost/mpl/pop_back_fwd.hpp>
#include <boost/mpl/aux_/config/typeof.hpp>

#if defined(BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES)

#   include <boost/units/unit/aux_/item.hpp>
#   include <boost/units/unit/aux_/tag.hpp>

namespace boost {
  namespace mpl {

template<>
struct pop_back_impl< aux::unit_tag >
{
    template< typename Unit > struct apply
    {
        typedef u_mask<Unit,0> type;
    };
};

}}

#endif // BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES

#endif // !defined BOOST_UNITS_UNIT_AUX_POP_BACK_HPP_INCLUDED
