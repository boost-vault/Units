
#if !defined BOOST_UNITS_UNIT_AUX_AT_HPP_INCLUDED
#  define BOOST_UNITS_UNIT_AUX_AT_HPP_INCLUDED


#include <boost/mpl/at_fwd.hpp>
#include <boost/mpl/long.hpp>
#include <boost/mpl/void.hpp>
#include <boost/mpl/aux_/nttp_decl.hpp>
#include <boost/mpl/aux_/type_wrapper.hpp>
#include <boost/mpl/aux_/value_wknd.hpp>
#include <boost/mpl/aux_/config/typeof.hpp>
#include <boost/mpl/aux_/config/ctps.hpp>

#include <boost/units/unit/aux_/tag.hpp>

namespace boost {
  namespace mpl {

#if defined(BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES)

template< typename Unit, long n_ >
struct u_at_impl
{
    typedef long_< (Unit::lower_bound_::value + n_) > index_;
    typedef __typeof__( Unit::item_(index_()) ) type;
};


template< typename Unit, long n_ >
struct u_at
    : aux::wrapped_type< typename u_at_impl<Unit,n_>::type >
{
};

template<>
struct at_impl< aux::unit_tag >
{
    template< typename Unit, typename N > struct apply
        : u_at<
              Unit
            , BOOST_MPL_AUX_VALUE_WKND(N)::value
            >
    {
    };
};

#else

#   if !defined(BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION) \
    && !defined(BOOST_MPL_CFG_NO_NONTYPE_TEMPLATE_PARTIAL_SPEC)

template< typename Unit, BOOST_MPL_AUX_NTTP_DECL(long, n_) > struct u_at;

template< BOOST_MPL_AUX_NTTP_DECL(long, n_) >
struct at_impl< aux::unit_tag<n_> >
{
    template< typename Unit, typename N > struct apply
#if !defined(__BORLANDC__)
        : u_at<
              Unit
            , BOOST_MPL_AUX_VALUE_WKND(N)::value
            >
    {
#else
    {
        typedef typename u_at<
              Unit
            , BOOST_MPL_AUX_VALUE_WKND(N)::value
            >::type type;
#endif
    };
};

#   else

namespace aux {

template< BOOST_MPL_AUX_NTTP_DECL(long, n_) > struct u_at_impl
{
    template< typename V > struct result_;
};

// to work around ETI, etc.
template<> struct u_at_impl<-1>
{
    template< typename V > struct result_
    {
        typedef void_ type;
    };
};

} // namespace aux

template< typename T, BOOST_MPL_AUX_NTTP_DECL(long, n_) >
struct u_at
    : aux::u_at_impl<n_>::template result_<T>
{
};

#   endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

#endif // BOOST_MPL_CFG_TYPEOF_BASED_SEQUENCES

}}

#endif // !defined BOOST_UNITS_UNIT_AUX_AT_HPP_INCLUDED
