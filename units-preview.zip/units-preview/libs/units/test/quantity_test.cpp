
#include <boost/units/quantity.hpp>
using namespace boost::units;

#include <iostream>

void quantity_test_constructors () {
  std::cout << "BEGIN quantity_test_constructors" << std::endl;

  quantity < length<> > q1;
  quantity < length<> > q2 (q1);
  q1 = q2;

  // template constructor tested in quantity_test_other_ops().

  std::cout << "END quantity_test_constructors" << std::endl;
}

#include <cassert>

void quantity_test_comparison_ops () {
  std::cout << "BEGIN quantity_test_comparison_ops" << std::endl;

  quantity < length<> > q1;
  // just basic checks for now.  test actual values later.
  assert (q1 == q1);
  assert (!(q1 < q1));

  std::cout << "END quantity_test_comparison_ops" << std::endl;
}

void quantity_test_arithmetic_ops () {
  std::cout << "BEGIN quantity_test_arithmetic_ops" << std::endl;

  quantity < length<> > q1;
  +q1;
  -q1;
  q1 * 2;
  q1 / 2;
  q1 / q1;
  q1 + q1;
  q1 - q1;

  std::cout << "END quantity_test_arithmetic_ops" << std::endl;
}

void quantity_test_arithmetic_assign () {
  std::cout << "BEGIN quantity_test_arithmetic_assign" << std::endl;

  quantity < length<> > q1;
  q1 *= 2;
  q1 /= 2;
  q1 += q1;
  q1 -= q1;

  std::cout << "END quantity_test_arithmetic_assign" << std::endl;
}

void quantity_test_other_ops () {
  std::cout << "BEGIN quantity_test_other_ops" << std::endl;

  quantity < length<> > q1;
  quantity < length<-1> > q2;
  q1 * q2;
  quantity < length<0> > q3 = q1 * q2;
  quantity < length<0> > q4 (q1 * q2);
  //quantity < length<> > q5 (q1 * q2); compile-error

  typedef dimension < length<> > d1;
  typedef dimension < mass<> > d2;
  typedef dimension < length<>, mass<> > d3;
  quantity < d1 > v1;
  quantity < d2 > v2;
  quantity < d3 > v3 (v1 * v2);

  std::cout << "END quantity_test_other_ops" << std::endl;
}

int main () {
  quantity_test_constructors ();
  quantity_test_comparison_ops ();
  quantity_test_arithmetic_ops ();
  quantity_test_arithmetic_assign ();
  quantity_test_other_ops ();
  //quantity_test_value_types ();
  return 0;
}

