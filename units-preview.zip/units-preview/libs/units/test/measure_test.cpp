
#include <boost/units/length_unit.hpp>
#include <boost/units/mass_unit.hpp>
using namespace boost::units;

#include <iostream>
#include <cassert>

#include <boost/units/dimension.hpp>
#include <boost/units/length.hpp>
#include <boost/units/quantity.hpp>

typedef quantity < dimension < length<> > > length_quantity;

void measure_test_constructors () {
  std::cout << "BEGIN measure_test_constructors" << std::endl;

  // standard unit

  meters m1;
  meters m2 (m1);
  m1 = m2;

  meters m3 (1);
  assert (m3.value () == 1);
  m1 = 3;
  assert (m1.value () == 3);

  length_quantity q1 (m3);
  q1 = m1;
  meters m4 (q1);
  assert (m4.value () == 3);
  m2 = q1;
  assert (m2.value () == 3);

  // non-standard unit

  feet f1 (1);
  assert (f1.value () == 1);
  f1 = 3;
  assert (f1.value () == 3);

  feet f2 (2);
  length_quantity q2 (f2);
  q2 = f1;
  feet f3 (q2);
  assert (f3.value () == 3);
  f2 = q2;
  assert (f2.value () == 3);

  // mixed units

  m1 = f2;
  assert (m1.value() > 0.9143 && m1.value() < 0.9145);
  feet f4 (m1);
  assert (f4.value() > 2.999 && f4.value() < 3.001);

  //pounds p1 = f1; compile error
  //f1 = p1; compile error

  std::cout << "END measure_test_constructors" << std::endl;
}

#include <utility>
using namespace std::rel_ops;

void measure_test_comparison_ops () {
  std::cout << "BEGIN measure_test_comparison_ops" << std::endl;

  meters m1 = 1, m2 = 2;
  assert (m1 == m1);
  assert (m1 != m2);
  assert (m1 < m2);
  assert (m1 <= m1);
  assert (m2 >= m1);
  assert (m2 > m1);

  std::cout << "END measure_test_comparison_ops" << std::endl;
}

#include <utility>
using namespace std::rel_ops;

void measure_test_arithmetic_ops () {
  std::cout << "BEGIN measure_test_arithmetic_ops" << std::endl;

  meters m1 = 1;
  assert (+m1 == m1);
  meters m2 = -1;
  assert (-m1 == m2);
  m2 = m1 * 2;
  assert (m2.value() >= 2 && m2.value() <= 2);
  m2 = m1 / 2;
  assert (m2.value() >= 0.5 && m2.value() <= 0.5);
  m2 = m1 / m2;
  assert (m2.value() >= 2 && m2.value() <= 2);
  m2 = m1 + m2;
  assert (m2.value() >= 3 && m2.value() <= 3);
  m2 = m1 - m2;
  assert (m2.value() >= -2 && m2.value() <= -2);

  //feet f1 = 1;
  //TODO: Repeat operations above using f1 as m2.

  std::cout << "END measure_test_arithmetic_ops" << std::endl;
}

void measure_test_arithmetic_assign () {
  std::cout << "BEGIN measure_test_arithmetic_assign" << std::endl;

  meters m1;
  m1 *= 2;
  m1 /= 2;
  m1 += m1;
  m1 -= m1;

  std::cout << "END measure_test_arithmetic_assign" << std::endl;
}

void measure_test_other_ops () {
  std::cout << "BEGIN measure_test_other_ops" << std::endl;

  meters m1;
  typedef measure < unit < meter<-1> > > inverse_meters;
  inverse_meters m2;
  m1 * m2;
  typedef measure < unit < meter<0> > > no_meters;
  //no_meters m3 = m1 * m2;
  no_meters m4 (m1 * m2);
  //meters m5 (m1 * m2); compile-error
/*
  typedef dimension < meter<> > u1;
  typedef dimension < mass<> > u2;
  typedef dimension < meter<>, mass<> > u3;
  measure < u1 > v1;
  measure < u2 > v2;
  measure < u3 > v3 (v1 * v2);
*/
  std::cout << "END measure_test_other_ops" << std::endl;
}

int main () {
  measure_test_constructors ();
  measure_test_comparison_ops ();
  measure_test_arithmetic_ops ();
  measure_test_arithmetic_assign ();
  measure_test_other_ops ();
  return 0;
}

