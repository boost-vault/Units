// Copyright 2006 Ben Strasser.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#ifndef UNITS_DEBUG_HPP
#define UNITS_DEBUG_HPP
#include "quantity.hpp"
#include "compile_time_number.hpp"
#include <boost/lexical_cast.hpp>
#include <string>
#include <typeinfo>
namespace compile_time_number{
	template<class Num>
	std::string inspect(){
		// Avoid linker errors on some compilers
		const int num = Num::num;
		const unsigned denom = Num::denom;
		
		std::string str = boost::lexical_cast<std::string>(num);
		if(Num::denom != 1){
			str += '/';
			str += boost::lexical_cast<std::string>(denom);
		}
		return str;
	}
}

namespace units{
	namespace ctn = ::compile_time_number;
	
	namespace detail{
		template<class Tlist, bool first, bool end = is_end<Tlist>::value>
		struct inspector:inspector<typename Tlist::next, false>
		{
			static std::string run(){
				std::string str = inspector<typename Tlist::next, false>::run();
				str += '[';
				str += typeid(typename Tlist::quan).name();
				str += ']';
				if(!ctn::equal<typename Tlist::pow, ctn::rational<1> >::value){
					str += '^';
					str += ctn::inspect<typename Tlist::pow>();
				}
				if(!first)
					str += " * ";
				return str;
			}
		};
		
		template<class Tlist, bool first>
		struct inspector<Tlist, first, true>{
			static std::string run(){
				if(first)
					return std::string("{scalar}");
				else 
					return std::string();
			}
		};
		
	}
	
	template<class Tlist>
	std::string inspect(){
		return detail::inspector<Tlist, true>::run();
	}
};
#endif
