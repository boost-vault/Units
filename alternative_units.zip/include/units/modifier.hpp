// Copyright 2006 Ben Strasser.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#ifndef MODIFIER_HPP
#define MODIFIER_HPP
#include <boost/mpl/assert.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/type_traits/integral_constant.hpp>
#include "compile_time_number.hpp"

namespace units{
	namespace ctn = ::compile_time_number;
	
	// ---------------------------------------------------------//
	
	template<class Tfrom_mod, class Tto_mod, class Traw, class Tconverter>
	void do_conversion(Traw&num, const Tconverter&con);
	
	template<class Tfrom_mod, class Tto_mod, class Traw>
	void do_conversion(Traw&num);
	
	// ---------------------------------------------------------//
	
	template<class Tcan>
	struct modifier_base{
		typedef Tcan canonic;
	};
	
	template<class Tmod>
	struct is_canonic:
		boost::is_same<Tmod, typename Tmod::canonic>{};
	
	// ---------------------------------------------------------//
			
	namespace detail{
		template<class Tfrom_mod, class Tto_mod, 
			// Both modifiers must not be canonic
			bool canonic = is_canonic<Tto_mod>::value && is_canonic<Tfrom_mod>::value>
		struct convert_helper{
			BOOST_MPL_ASSERT_MSG(false, CAN_NOT_DEDUCE_UNIT_MODIFIER_CONVERSION_FOR, (Tfrom_mod, Tto_mod));
		};
		
		#ifndef NO_UNIT_MODIFIER_CONVERSION_DEDUCTION
		// This is the heart of the deduction chain mechanisme
		template<class Tfrom_mod, class Tto_mod>
		struct convert_helper<Tfrom_mod, Tto_mod, false>{
			template<class Tnum, class Tconverter>
			static const void run(Tnum&num, const Tconverter&con){
				typedef typename Tfrom_mod::canonic from_canonic;
				typedef typename Tto_mod::canonic to_canonic;
	
				do_conversion<Tfrom_mod, from_canonic>(num, con);
				do_conversion<from_canonic, to_canonic>(num, con);
				do_conversion<to_canonic, Tto_mod>(num, con);
			}
		};
		#endif
		
		
	}
	
	// This is the least specialized version of convert so the last one that the compiler will find.
	template<class Tfrom_mod, class Tto_mod, class Traw, class Tconverter>
	void convert(Tfrom_mod, Tto_mod, Traw&num, const Tconverter&con){
		detail::convert_helper<Tfrom_mod, Tto_mod>::run(num, con);
	}
	
	// ---------------------------------------------------------//
	
	// A modifier that expresses relations using multiples of some arbitrary origin.
	template<class Tnum>
	struct multiple_modifier:public modifier_base<multiple_modifier<ctn::rational<1> > >
		{};
	
	// Specialized modifier converter
	template<class Tfrom_num, class Tto_num, class Traw, class Tconverter>
	void convert(multiple_modifier<Tfrom_num>, multiple_modifier<Tto_num>, Traw&num, const Tconverter&){
		typedef typename ctn::divide<Tfrom_num, Tto_num>::type direct;
		num *= direct::num;
		num /= direct::denom;
	}
		
	// ---------------------------------------------------------//
	
	namespace detail{
		template<class Tfrom_mod, class Tto_mod, class Traw, class Tconverter>
		void do_global_conversion(Traw&num, const Tconverter&con){
			// unqualified name to allow Koenig lookup
			convert(Tfrom_mod(), Tto_mod(), num, con);
		}
	}
	
	template<class Tderived_converter>
	class converter{
	public:
		template<class Tfrom_mod, class Tto_mod, class Traw>
		void convert(Tfrom_mod, Tto_mod, Traw&num)const{
			detail::do_global_conversion<Tfrom_mod, Tto_mod>(num, static_cast<const Tderived_converter&>(*this));
		}
	};
	
	class global_converter:public converter<global_converter>{
	public:
		using converter<global_converter>::convert;
	};
	
	// ---------------------------------------------------------//
	
	namespace detail{
		template<class Tfrom_mod, class Tto_mod>
		struct do_conversion_helper{
			template<class Traw, class Tconverter>
			static void run(Traw&num, const Tconverter&con){
				/*cerr<<"["<<typeid(Tfrom_mod).name()<<"] -> ["<<typeid(Tto_mod).name()<<"]"<<endl;
				cin.get();*/
				
				con.convert(Tfrom_mod(), Tto_mod(), num);
			}
		};
		
		template<class Tmod>
		struct do_conversion_helper<Tmod, Tmod>{
			template<class Traw, class Tconverter>
			static void run(Traw&num, const Tconverter&con){}
		};
	}
	
	template<class Tfrom_mod, class Tto_mod, class Traw, class Tconverter>
	void do_conversion(Traw&num, const Tconverter&con){
		detail::do_conversion_helper<Tfrom_mod, Tto_mod>::run(num, con);
	}
	
	template<class Tfrom_mod, class Tto_mod, class Traw>
	void do_conversion(Traw&num){
		detail::do_conversion_helper<Tfrom_mod, Tto_mod>::run(num, global_converter());
	}
	
	// ---------------------------------------------------------//
	
	namespace stock{
		struct no_conversion:modifier_base<no_conversion>{};
			
		typedef multiple_modifier<ctn::rational <1, 1000000> >micro;
		typedef multiple_modifier<ctn::rational <1, 1000> >milli;
		typedef multiple_modifier<ctn::rational <1, 100> >centi;
		typedef multiple_modifier<ctn::rational <1, 10> >deci;
		typedef multiple_modifier<ctn::rational <1, 1> >one; // better name ?
		typedef multiple_modifier<ctn::rational <10, 1> >deca;
		typedef multiple_modifier<ctn::rational <100, 1> >heca;
		typedef multiple_modifier<ctn::rational <1000, 1> >kilo;
		typedef multiple_modifier<ctn::rational <1000000, 1> >mega;
	}
}
#endif

