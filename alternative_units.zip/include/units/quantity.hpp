// Copyright 2006 Ben Strasser.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#ifndef QUANTITY_HPP
#define QUANTITY_HPP
#include "compile_time_number.hpp"
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/mpl/if.hpp>
namespace units{
	namespace ctn = ::compile_time_number;
	namespace mpl = boost::mpl;
	
	namespace detail{
		template<class Tquan>
		struct is_end:
			boost::is_same<Tquan, typename Tquan::next>{};
		
		struct quan_list_end{
			typedef quan_list_end next;
		};
		
		template<class Tnext, class Tquan, class Tpow>
		struct quan_node{
			typedef Tnext next;
			typedef Tquan quan;
			typedef Tpow pow;
		};
		
		template<class Tlist, class Tquan, class Tpow>
		struct push_front{
			typedef quan_node<Tlist, Tquan, Tpow> type;
		};
		
		template<class Tlist>
		struct pop_front{
			typedef typename Tlist::next type;
		};
		
		// --------------------------------------------------------- //
		
		template<class Tlist, template<class>class Tcond, bool end = is_end<Tlist>::value>
		struct remove_from_list{
			typedef typename 
				mpl::if_<Tcond<typename Tlist::pow>,
					typename Tlist::next,
					typename push_front<
						typename remove_from_list<typename Tlist::next, Tcond>::type,
						typename Tlist::quan,
						typename Tlist::pow
					>::type
				>::type
			type;
		};
		
		template<class Tlist, template<class>class Tcond>
		struct remove_from_list<Tlist, Tcond, true>{
			typedef quan_list_end type;
		};
		
		// --------------------------------------------------------- //
		
		// The element in the list is seen as the left side operant for Tcombiner
		template<class Tlist, class Tquan, class Tpow, template<class, class>class Tcombiner, bool end = is_end<Tlist>::value>
		struct insert_into_list_internal{
			typedef typename 
				mpl::if_<boost::is_same<typename Tlist::quan, Tquan>,
					typename push_front<
						typename pop_front<Tlist>::type, 
						Tquan, 
						typename Tcombiner<typename Tlist::pow, Tpow>::type
					>::type,
					typename push_front<
						typename insert_into_list_internal<
							typename pop_front<Tlist>::type, 
							Tquan, Tpow, Tcombiner
						>::type, 
						typename Tlist::quan, 
						typename Tlist::pow
					>::type
				>::type
			type;
		};
		
		template<class Tlist, class Tquan, class Tpow, template<class, class>class Tcombiner>
		struct insert_into_list_internal<Tlist, Tquan, Tpow, Tcombiner, true>{
			typedef typename 
				push_front<
					quan_list_end, 
					Tquan, 
					typename Tcombiner<ctn::rational<0>, Tpow>::type
				>::type
			type;
		};
		
		template<class Tlist, class Tquan, class Tpow, template<class, class>class Tcombiner>
		struct insert_into_list{
			typedef typename
				remove_from_list<
					typename insert_into_list_internal<Tlist, Tquan, Tpow, Tcombiner>::type, 
					ctn::is_null
				>::type
			type;
		};	
	}	
		
	// Combines 2 quantity lists into one by combining the powers using Tcombine. The elements of
	// Tlist1 are regarded as the left side operants.
	template<class Tlist1, class Tlist2, template<class, class>class Tcombiner, bool end = detail::is_end<Tlist2>::value>
	struct combine{
		typedef typename 
			combine<
				typename detail::insert_into_list<
					Tlist1,
					typename Tlist2::quan,
					typename Tlist2::pow,
					Tcombiner
				>::type,
				typename detail::pop_front<Tlist2>::type,
				Tcombiner
			>::type
		type;
	};
	
	template<class Tlist1, class Tlist2, template<class, class>class Tcombiner>
	struct combine<Tlist1, Tlist2, Tcombiner, true>{
		typedef Tlist1 type;
	};
	
	// --------------------------------------------------------- //
	
	template<class Tlist, class Tquan, bool end = detail::is_end<Tlist>::value>
	struct get_base_quantity_power{
		typedef typename
			mpl::if_<boost::is_same<typename Tlist::quan, Tquan>,
				typename Tlist::pow,
				typename get_base_quantity_power<
					typename detail::pop_front<Tlist>::type,
					Tquan
				>::type
			>::type
		type;
	};
	
	template<class Tlist, class Tquan>
	struct get_base_quantity_power<Tlist, Tquan, true>{
		typedef ctn::rational<0> type;
	};
	
	// --------------------------------------------------------- //
	
	namespace detail{
		template<class Tlist, class Tquan, bool end = detail::is_end<Tlist>::value>
		struct remove_quantity_from_list{
			typedef typename
				mpl::if_<boost::is_same<typename Tlist::quan, Tquan>,
					typename remove_quantity_from_list<
						typename pop_front<Tlist>::type,
						Tquan
					>::type,
					typename push_front<
						typename remove_quantity_from_list<
							typename pop_front<Tlist>::type,
							Tquan
						>::type,
						typename Tlist::quan,
						typename Tlist::pow
					>::type
				>::type
			type;
		};
		
		template<class Tlist, class Tquan>
		struct remove_quantity_from_list<Tlist, Tquan, true>{
			typedef quan_list_end type;
		};
	}
	
	// --------------------------------------------------------- //
	
	template<class Tlist1, class Tlist2, bool end1 = detail::is_end<Tlist1>::value, bool end2 = detail::is_end<Tlist2>::value>
	struct is_same_quantity;
	
	template<class Tlist1, class Tlist2>
	struct is_same_quantity<Tlist1, Tlist2, true, true>:
		boost::true_type{};	
	
	template<class Tlist1, class Tlist2>
	struct is_same_quantity<Tlist1, Tlist2, false, true>:
		boost::false_type{};	
	
	template<class Tlist1, class Tlist2>
	struct is_same_quantity<Tlist1, Tlist2, true, false>:
		boost::false_type{};	
	
	template<class Tlist1, class Tlist2>
	struct is_same_quantity<Tlist1, Tlist2, false, false>:
		mpl::if_<
			ctn::equal<
				typename Tlist1::pow,
				typename get_base_quantity_power<
					Tlist2, 
					typename Tlist1::quan
				>::type
			>,
			is_same_quantity<
				typename detail::pop_front<Tlist1>::type,
				typename detail::remove_quantity_from_list<Tlist2, typename Tlist1::quan>::type
			>,
			boost::false_type
		>::type{};	
		
	// --------------------------------------------------------- //
	
	// Combines 2 quantity lists by multiplication
	template<class Tlist1, class Tlist2>
	struct combine_by_multiplication:
		combine<Tlist1, Tlist2, ctn::add>{};
	
	// Combines 2 quantity lists by division
	template<class Tlist1, class Tlist2>
	struct combine_by_division:
		combine<Tlist1, Tlist2, ctn::substract>{};
	
	// --------------------------------------------------------- //
	
	template<class Tlist, class Tnum, template<class, class>class Tcombiner = ctn::multiply, bool end = detail::is_end<Tlist>::value>
	struct raise_to:
		detail::push_front<
			typename raise_to<typename detail::pop_front<Tlist>::type, Tnum, Tcombiner>::type,
			typename Tlist::quan,
			typename Tcombiner<typename Tlist::pow, Tnum>::type
		>::type
	{
		typedef typename 
		detail::push_front<
			typename raise_to<typename detail::pop_front<Tlist>::type, Tnum, Tcombiner>::type,
			typename Tlist::quan,
			typename Tcombiner<typename Tlist::pow, Tnum>::type
		>::type
		type;
	};
	
	template<class Tlist, class Tnum, template<class, class>class Tcombiner>
	struct raise_to<Tlist, Tnum, Tcombiner, true>{
		typedef detail::quan_list_end type;
	};
			
	// --------------------------------------------------------- //
	
	typedef detail::quan_list_end no_quantity;
			
	template<class Tquan>
	struct is_scalar:public detail::is_end<Tquan>{};
		
	// --------------------------------------------------------- //
	
	template<class Tbase>
	struct base_quantity:
		detail::push_front<detail::quan_list_end, Tbase, ctn::rational<1> >::type{};
		
	// --------------------------------------------------------- //
	
	#ifndef MAX_QUANTITY_COMBINATION
	#  define MAX_QUANTITY_COMBINATION 5
	#endif
	
	#define TEMPLATE_ARG(z, n, data)\
		, class Q##n = no_quantity, class P##n = ctn::rational<1>
	
	#define INHERITANCE_TREE_OPEN(z, n, data)\
		typename combine_by_multiplication<
	
	#define INHERITANCE_TREE_CLOSE(z, n, data)	,\
			typename raise_to<Q##n, P##n>::type\
		>::type
	
	template<class Q, class P = ctn::rational<1> BOOST_PP_REPEAT(MAX_QUANTITY_COMBINATION, TEMPLATE_ARG, nil)>
	struct irrational_quantity:combine_by_multiplication<
			BOOST_PP_REPEAT(MAX_QUANTITY_COMBINATION, INHERITANCE_TREE_OPEN, nil)
				detail::quan_list_end
			BOOST_PP_REPEAT(MAX_QUANTITY_COMBINATION, INHERITANCE_TREE_CLOSE, nil),
		typename raise_to<Q, P>::type>::type{};
	
	#undef TEMPLATE_ARG
	#undef INHERITANCE_TREE_OPEN
	#undef INHERITANCE_TREE_CLOSE
	
	#define TEMPLATE_ARG(z, n, data)\
		, class Q##n = no_quantity, int P##n = 1
	
	#define INHERITANCE_LIST_ARG(z, n, data)\
		, Q##n, ctn::rational<P##n>
	
	template<class Q, int P = 1 BOOST_PP_REPEAT(MAX_QUANTITY_COMBINATION, TEMPLATE_ARG, nil)>
	struct quantity:irrational_quantity<Q, ctn::rational<P> BOOST_PP_REPEAT(MAX_QUANTITY_COMBINATION, INHERITANCE_LIST_ARG, nil)>{};
	
	#undef TEMPLATE_ARG
	#undef INHERITANCE_LIST_ARG
	
};
#endif
