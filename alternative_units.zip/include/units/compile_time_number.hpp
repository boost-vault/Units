// Copyright 2006 Ben Strasser.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#ifndef COMPILE_TIME_NUMBER_HPP
#define COMPILE_TIME_NUMBER_HPP
#include <boost/type_traits/integral_constant.hpp>
namespace compile_time_number{
	namespace detail{
		template<class Tn>
		struct abs:
			boost::integral_constant<unsigned, (Tn::value>=0) ? Tn::value : -Tn::value>
		{};
		
		template<class Tn>
		struct sign:
			boost::integral_constant<int, (Tn::value>=0) ? 1 : -1>
		{};
		
		template<class Ta, class Tb, bool a_null = (Ta::value == 0), bool b_null = (Tb::value == 0)>
		struct gcd:
			gcd<boost::integral_constant<unsigned, Tb::value % Ta::value>, Ta>
		{};
			
		
		template<class Ta, class Tb>
		struct gcd<Ta, Tb, false, true>:
			Ta
		{};
			
		template<class Ta, class Tb>
		struct gcd<Ta, Tb, true, false>:
			Tb
		{};
			
		template<class Ta, class Tb>
		struct gcd<Ta, Tb, true, true>:
			boost::integral_constant<unsigned, 0>
		{};
	}

	template<int Tnum, unsigned Tdenom = 1>
	struct rational{
		static const int num = Tnum;
		static const unsigned denom = Tdenom;
		
		typedef boost::integral_constant<int, Tnum> num_type;
		typedef boost::integral_constant<unsigned, Tdenom> denom_type;
	};
	
	template<int Tnum>
	struct rational<Tnum, 0>;
	
	template<class Tn>
	struct reduce{
		typedef 
			detail::gcd<detail::abs<typename Tn::num_type>, typename Tn::denom_type>
		gcd;
		typedef 
			rational<
				Tn::num / static_cast<int>(gcd::value), 
				Tn::denom / gcd::value
			>
		type;
	};
	
	template<class n1, class n2>
	struct add{
		typedef
			typename reduce<
				rational<
					n1::num * static_cast<int>(n2::denom) + n2::num * static_cast<int>(n1::denom),
					n1::denom * n2::denom
				>
			>::type
		type;
	};
	
	template<class n1, class n2>
	struct substract{
		typedef
			typename reduce<
				rational<
					n1::num * static_cast<int>(n2::denom) - n2::num * static_cast<int>(n1::denom),
					n1::denom * n2::denom
				>
			>::type
		type;
	};
	
	template<class n1, class n2>
	struct multiply{
		typedef
			typename reduce<
				rational<
					n1::num * n2::num,
					n1::denom * n2::denom
				>
			>::type
		type;
	};
	
	template<class rat, int n>
	struct multiply_by_int{
		typedef
			typename reduce<
				rational<
					rat::num *  n,
					rat::denom
				>
			>::type
		type;
	};
	
	template<class n1, class n2>
	struct divide{
		typedef
			typename reduce<
				rational<
					n1::num * n2::denom *  detail::sign<typename n2::num_type>::value,
					n1::denom * detail::abs<typename n2::num_type>::value 
				>
			>::type
		type;
	};
	
	template<class rat, int n>
	struct divide_by_int{
		typedef
			typename reduce<
				rational<
					rat::num *  detail::sign<boost::integral_constant<int, n> >::value,
					rat::denom * detail::abs<boost::integral_constant<int, n> >::value
				>
			>::type
		type;
	};
	
	template<class n1, class n2>
	struct equal:boost::integral_constant<bool, 
		n1::num * static_cast<int>(n2::denom) == n2::num * static_cast<int>(n1::denom)
	>{};
	
	template<class n1, class n2>
	struct smaller:boost::integral_constant<bool, 
		n1::num * static_cast<int>(n2::denom) < n2::num * static_cast<int>(n1::denom)
	>{};
		
	template<class n>
	struct is_null:boost::integral_constant<bool, n::num == 0>{};
};
#endif
