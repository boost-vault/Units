// Copyright 2006 Ben Strasser.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#ifndef UNIT_HPP
#define UNIT_HPP
#include <boost/utility/enable_if.hpp>
#include <boost/mpl/and.hpp>
#include <boost/type_traits/is_convertible.hpp>
#include <cmath>
#include "quantity.hpp"
#include "modifier.hpp"
namespace units{
	namespace ctn = ::compile_time_number;
	namespace mpl = boost::mpl;
	
	template<class Tquan, class Tmod = stock::no_conversion, class Traw = double>
	class unit{
	public:
		typedef Tquan quantity_type;
		typedef Tmod modifier_type;
		typedef Traw raw_type;
	
		unit(){}
	
		// Constructors and assignments
		template<class Tother_raw>
		explicit unit(Tother_raw num, 
			typename boost::enable_if<
				boost::is_convertible<Tother_raw, Traw>
			>::type* dummy = 0):
			num(num){}
	
		template<class Tother_quan, class Tother_mod, class Tother_raw>
		unit(const unit<Tother_quan, Tother_mod, Tother_raw>&other,
			typename boost::enable_if<
				mpl::and_<
					boost::is_convertible<Tother_raw, Traw>,
					is_same_quantity<Tother_quan, Tquan>
				>
			>::type* dummy = 0):num(other.raw()){
			do_conversion<Tother_mod, Tmod>(num);
		}
		
		
		template<class Tother_quan, class Tother_mod, class Tother_raw>
		typename boost::enable_if<
			mpl::and_<
				boost::is_convertible<Tother_raw, Traw>,
				is_same_quantity<Tother_quan, Tquan>
			>,
			unit&
		>::type
		operator = (const unit<Tother_quan, Tother_mod, Tother_raw>&other){
			num = other.raw();
			do_conversion<Tother_mod, Tmod>(num);
			return *this;
		}
		
		// Addition and substraction with other units
		template<class Tother_quan, class Tother_mod, class Tother_raw>
		typename boost::enable_if<
			mpl::and_<
				boost::is_convertible<Tother_raw, Traw>,
				is_same_quantity<Tother_quan, Tquan>
			>,
			unit&
		>::type
		operator += (const unit<Tother_quan, Tother_mod, Tother_raw>&other){
			Tother_raw temp(other.raw());
			do_conversion<Tother_mod, Tmod>(temp);
			num += temp;
			return *this;
		}
		
		
		template<class Tother_quan, class Tother_mod, class Tother_raw>
		typename boost::enable_if<
			mpl::and_<
				boost::is_convertible<Tother_raw, Traw>,
				is_same_quantity<Tother_quan, Tquan>
			>,
			unit&
		>::type
		operator -= (const unit<Tother_quan, Tother_mod, Tother_raw>&other){
			Tother_raw temp(other.raw());
			do_conversion<Tother_mod, Tmod>(temp);
			num -= temp;
			return *this;
		}
		
		/*
		// Addition and substraction with scalars (works only for units without quantities)
		// (Disabled because of modifier problems)
		template<class Tother_raw>
		typename boost::enable_if<
			mpl::and_<
				boost::is_convertible<Tother_raw, Traw>,
				is_scalar<Tquan>
			>,
			unit&
		>::type
		operator += (const Tother_raw&other){
			num += other;
			return *this;
		}
		
		template<class Tother_raw>
		typename boost::enable_if<
			mpl::and_<
				boost::is_convertible<Tother_raw, Traw>,
				is_scalar<Tquan>
			>,
			unit&
		>::type
		operator -= (const Tother_raw&other){
			num -= other;
			return *this;
		}*/
		
		// Multiplication and division with scalars
		template<class Tother_raw>
		typename boost::enable_if<
			boost::is_convertible<Tother_raw, Traw>,
			unit&
		>::type
		operator *= (const Tother_raw&other){
			num *= other;
			return *this;
		}
		
		template<class Tother_raw>
		typename boost::enable_if<
			boost::is_convertible<Tother_raw, Traw>,
			unit&
		>::type
		operator /= (const Tother_raw&other){
			num /= other;
			return *this;
		}
		
		// Multiplication and division with quantitiyless units
		template<class Tother_quan, class Tother_mod, class Tother_raw>
		typename boost::enable_if<
			mpl::and_<
				boost::is_convertible<Tother_raw, Traw>,
				is_scalar<Tother_quan>
			>,
			unit&
		>::type
		operator *= (const unit<Tother_quan, Tother_mod, Tother_raw>&other){
			Tother_raw temp(other.raw());
			do_conversion<Tother_mod, Tmod>(temp);
			num *= temp;
			return *this;
		}
		
		template<class Tother_quan, class Tother_mod, class Tother_raw>
		typename boost::enable_if<
			mpl::and_<
				boost::is_convertible<Tother_raw, Traw>,
				is_scalar<Tother_quan>
			>,
			unit&
		>::type
		operator /= (const unit<Tother_quan, Tother_mod, Tother_raw>&other){
			Tother_raw temp(other.raw());
			do_conversion<Tother_mod, Tmod>(temp);
			num /= temp;
			return *this;
		}
		
		// Access to the internal storage
		Traw&raw() { return num; }
		const Traw&raw()const { return num; }
	private:
		Traw num;
	};
	
	//
	// Binary + and -
	//
	template<class Tquan, class Tmod1, class Tmod2, class Traw1, class Traw2>
	typename boost::enable_if<
		boost::is_convertible<Traw2, Traw1>,
		unit<Tquan, Tmod1, Traw1>
	>::type
	operator + (const unit<Tquan, Tmod1, Traw1>&a, const unit<Tquan, Tmod2, Traw2>&b){
		Traw2 temp(b.raw());
		do_conversion<Tmod2, Tmod1>(temp);
		return unit<Tquan, Tmod1, Traw1>(a.raw() + temp);
	}
	
	template<class Tquan, class Tmod1, class Tmod2, class Traw1, class Traw2>
	typename boost::enable_if<
		boost::is_convertible<Traw2, Traw1>,
		unit<Tquan, Tmod1, Traw1>
	>::type
	operator - (const unit<Tquan, Tmod1, Traw1>&a, const unit<Tquan, Tmod2, Traw2>&b){
		Traw2 temp(b.raw());
		do_conversion<Tmod2, Tmod1>(temp);
		return unit<Tquan, Tmod1, Traw1>(a.raw() - temp);
	}
	
	//
	// Binary * and / between units
	//
	namespace detail{
		template<class Tquan1, class Tquan2, class Tmod, class Traw, template<class, class>class Tcombiner, 
			bool scalar=is_scalar<typename combine<Tquan1, Tquan2, Tcombiner>::type>::value>
		struct unit_selector{
			typedef
				unit<typename combine<Tquan1, Tquan2, Tcombiner>::type, Tmod, Traw>
			type;
		};
		
		/*
		// (Disabled because of modifier problems)
		template<class Tquan1, class Tquan2, class Tmod, class Traw, template<class, class>class Tcombiner>
		struct unit_selector<Tquan1, Tquan2, Tmod, Traw, Tcombiner, true>{
			typedef
				Traw
			type;
		};*/
	}
	
	template<class Tquan1, class Tquan2, class Tmod1, class Tmod2, class Traw1, class Traw2>
	typename boost::enable_if<
		boost::is_convertible<Traw2, Traw1>,
		typename detail::unit_selector<Tquan1, Tquan2, Tmod1, Traw1, ctn::add>::type
	>::type
	operator * (const unit<Tquan1, Tmod1, Traw1>&a, const unit<Tquan2, Tmod2, Traw2>&b){
		Traw2 temp(b.raw());
		do_conversion<Tmod2, Tmod1>(temp);
		return typename detail::unit_selector<Tquan1, Tquan2, Tmod1, Traw1, ctn::add>::type(a.raw() * temp);
	}
	
	template<class Tquan1, class Tquan2, class Tmod1, class Tmod2, class Traw1, class Traw2>
	typename boost::enable_if<
		boost::is_convertible<Traw2, Traw1>,
		typename detail::unit_selector<Tquan1, Tquan2, Tmod1, Traw1, ctn::substract>::type
	>::type
	operator / (const unit<Tquan1, Tmod1, Traw1>&a, const unit<Tquan2, Tmod2, Traw2>&b){
		Traw2 temp(b.raw());
		do_conversion<Tmod2, Tmod1>(temp);
		return typename detail::unit_selector<Tquan1, Tquan2, Tmod1, Traw1, ctn::substract>::type(a.raw() / temp);
	}
	
	//
	// Binary * and / between units and scalars
	//
	template<class Tquan, class Tmod, class Traw1, class Traw2>
	typename boost::enable_if<
		boost::is_convertible<Traw2, Traw1>,
		unit<Tquan, Tmod, Traw1>
	>::type
	operator * (const unit<Tquan, Tmod, Traw1>&a, const Traw2&b){
		return unit<Tquan, Tmod, Traw1>(a.raw() * b);
	}
	
	template<class Tquan, class Tmod, class Traw1, class Traw2>
	typename boost::enable_if<
		boost::is_convertible<Traw2, Traw1>,
		unit<Tquan, Tmod, Traw1>
	>::type
	operator * (const Traw1&a, const unit<Tquan, Tmod, Traw2>&b){
		return unit<Tquan, Tmod, Traw2>(a * b.raw());
	}
	
	template<class Tquan, class Tmod, class Traw1, class Traw2>
	typename boost::enable_if<
		boost::is_convertible<Traw2, Traw1>,
		unit<Tquan, Tmod, Traw1>
	>::type
	operator / (const unit<Tquan, Tmod, Traw1>&a, const Traw2&b){
		return unit<Tquan, Tmod, Traw1>(a.raw() / b);
	}
	
	template<class Tquan, class Tmod, class Traw1, class Traw2>
	typename boost::enable_if<
		boost::is_convertible<Traw2, Traw1>,
		unit<Tquan, Tmod, Traw1>
	>::type
	operator / (const Traw1&a, const unit<Tquan, Tmod, Traw2>&b){
		return unit<Tquan, Tmod, Traw2>(a / b.raw());
	}
	
	//
	// Compairison operators
	//
	#define IMPLEMENT_COMP_OP(op)\
		template<class Tquan1, class Tquan2, class Tmod1, class Tmod2, class Traw1, class Traw2>\
		typename boost::enable_if<\
			mpl::and_<\
				boost::is_convertible<Traw2, Traw1>,\
				is_same_quantity<Tquan2, Tquan1>\
			>,\
			bool\
		>::type\
		operator op (const unit<Tquan1, Tmod1, Traw1>&a, const unit<Tquan2, Tmod2, Traw2>&b){\
			Traw2 temp(b.raw());\
			do_conversion<Tmod1, Tmod2>(temp);\
			return a.raw() op temp;\
		}
		
	IMPLEMENT_COMP_OP(==)
	IMPLEMENT_COMP_OP(!=)
	IMPLEMENT_COMP_OP(<)
	IMPLEMENT_COMP_OP(>)
	IMPLEMENT_COMP_OP(<=)
	IMPLEMENT_COMP_OP(>=)
	#undef IMPLEMENT_COMP_OP
			
	//
	// Casts
	//
	template<class Tto_mod, class Tquan, class Tfrom_mod, class Traw, class Tconverter>
	unit<Tquan, Tto_mod, Traw>modifier_cast(const unit<Tquan, Tfrom_mod, Traw>&n, const Tconverter&con ){
		Traw temp = n.raw();
		do_conversion<Tfrom_mod, Tto_mod>(temp, con);
		return unit<Tquan, Tto_mod, Traw>(temp);
	}
	
	template<class Tto_mod, class Tquan, class Tfrom_mod, class Traw>
	unit<Tquan, Tto_mod, Traw>modifier_cast(const unit<Tquan, Tfrom_mod, Traw>&n){
		Traw temp = n.raw();
		do_conversion<Tfrom_mod, Tto_mod>(temp);
		return unit<Tquan, Tto_mod, Traw>(temp);
	}
	
	template<class Tunit, class Tfrom_quan, class Tfrom_mod, class Tfrom_raw, class Tconverter>
	typename boost::enable_if<
		mpl::and_<
			boost::is_convertible<Tfrom_raw, typename Tunit::raw_type>,
			is_same_quantity<Tfrom_quan, typename Tunit::quantity_type>
		>,
		Tunit
	>::type
	unit_cast(const unit<Tfrom_quan, Tfrom_mod, Tfrom_raw>&n, const Tconverter&con){
		return modifier_cast<typename Tunit::modifier_type>(n, con);
	}
		
	template<class Tunit, class Tfrom_quan, class Tfrom_mod, class Tfrom_raw>
	typename boost::enable_if<
		mpl::and_<
			boost::is_convertible<Tfrom_raw, typename Tunit::raw_type>,
			is_same_quantity<Tfrom_quan, typename Tunit::quantity_type>
		>,
		Tunit
	>::type
	unit_cast(const unit<Tfrom_quan, Tfrom_mod, Tfrom_raw>&n){
		return modifier_cast<typename Tunit::modifier_type>(n);
	}
	
	//
	// Math functions
	//
	template<class Tquan, class Tmod, class Traw>
	unit<raise_to<Tquan, ctn::rational<1, 2> >, Tmod, Traw>sqrt(const unit<Tquan, Tmod, Traw>&n){
		return unit<raise_to<Tquan, ctn::rational<1, 2> >, Tmod, Traw>(sqrt(n.raw())); // To std:: or not to std:: that is the question!
	}
};
#endif
