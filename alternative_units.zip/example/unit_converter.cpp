// Copyright 2006 Ben Strasser.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#include<units/unit.hpp>
#include<units/compile_time_number.hpp>
#include<iostream>
#include<string>

namespace ctn = compile_time_number;

struct length:units::base_quantity<length>{};

typedef units::unit<length, units::multiple_modifier<ctn::rational<1000, 1> > >kilo_meter;
typedef units::unit<length, units::multiple_modifier<ctn::rational<100, 1> > >hecto_meter;
typedef units::unit<length, units::multiple_modifier<ctn::rational<10, 1> > >deca_meter;
typedef units::unit<length, units::multiple_modifier<ctn::rational<1, 1> > >meter;
typedef units::unit<length, units::multiple_modifier<ctn::rational<1, 10> > >deci_meter;
typedef units::unit<length, units::multiple_modifier<ctn::rational<1, 100> > >centi_meter;
typedef units::unit<length, units::multiple_modifier<ctn::rational<1, 1000> > >milli_meter;
	
	
typedef units::unit<length, units::multiple_modifier<ctn::rational<304, 1000> > >feet;

template<class Unit>
Unit read(std::istream&in){
	double n;
	in>>n;
	std::string unit;
	in>>unit;
	if(unit == "km")
		return kilo_meter(n);
	if(unit == "hm")
		return hecto_meter(n);
	if(unit == "dam")
		return deca_meter(n);
	if(unit == "m")
		return meter(n);
	if(unit == "dm")
		return deci_meter(n);
	if(unit == "cm")
		return centi_meter(n);
	if(unit == "mm")
		return milli_meter(n);
	if(unit == "ft")
		return feet(n);
	// error handling omitted
	return kilo_meter(0);
}

std::ostream&operator<<(std::ostream&out, kilo_meter n)	{ return out<<n.raw()<<"km"; }
std::ostream&operator<<(std::ostream&out, hecto_meter n)	{ return out<<n.raw()<<"hm"; }
std::ostream&operator<<(std::ostream&out, deca_meter n)	{ return out<<n.raw()<<"dam"; }
std::ostream&operator<<(std::ostream&out, meter n)		{ return out<<n.raw()<<"m"; }
std::ostream&operator<<(std::ostream&out, deci_meter n)	{ return out<<n.raw()<<"dm"; }
std::ostream&operator<<(std::ostream&out, centi_meter n)	{ return out<<n.raw()<<"cm"; }
std::ostream&operator<<(std::ostream&out, milli_meter n)	{ return out<<n.raw()<<"mm"; }
std::ostream&operator<<(std::ostream&out, feet n)		{ return out<<n.raw()<<"ft"; }

int main(){
	std::cout<<"Enter a value : ";
	
	meter val = read<meter>(std::cin);
	std::cout
		<<" = "<<units::unit_cast<kilo_meter>(val)<<std::endl
		<<" = "<<units::unit_cast<hecto_meter>(val)<<std::endl
		<<" = "<<units::unit_cast<deca_meter>(val)<<std::endl
		<<" = "<<units::unit_cast<meter>(val)<<std::endl
		<<" = "<<units::unit_cast<deci_meter>(val)<<std::endl
		<<" = "<<units::unit_cast<centi_meter>(val)<<std::endl
		<<" = "<<units::unit_cast<milli_meter>(val)<<std::endl
		<<" = "<<units::unit_cast<feet>(val)<<std::endl
	;
}
