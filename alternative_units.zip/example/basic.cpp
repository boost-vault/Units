// Copyright 2006 Ben Strasser.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#include <units/unit.hpp>
#include <iostream>
using std::cout;
using std::cin;
using std::endl;

// Define the quantities that we'll be using 
struct length:units::base_quantity<length>{};
struct time_:units::base_quantity<time_>{};
struct mass:units::base_quantity<mass>{};
	
typedef units::quantity<length, 1, time_, -1> velocity;
typedef units::quantity<velocity, 1, time_, -1> acceleration;
	
typedef units::quantity<acceleration, 1, mass, 1, length, 1> energie;
	
// Define the units
typedef units::unit<length> meter;
typedef units::unit<time_> second;
typedef units::unit<mass> kilo_gram;
typedef units::unit<energie> joule;
	

int main(){
	meter d;
	second t;
	kilo_gram m;
	
	cout<<"How much do you weight? : ";
	cin>>m.raw();
	cout<<"How far did you walk? : ";
	cin>>d.raw();
	cout<<"How long did you need? : ";
	cin>>t.raw();
	
	joule e = (m * d * d) / (t * t);
	cout<<"Your cinetique energie was : "<<e.raw()<<endl;
}
