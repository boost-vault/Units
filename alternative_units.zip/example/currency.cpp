// Copyright 2006 Ben Strasser.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#include<iostream>
#include<units/unit.hpp>

struct money:units::base_quantity<money>{};
	
// Define the different currencies (dollar is used as intermediate currency between euro and yen)
struct dollar_mod:units::modifier_base<dollar_mod>{};
struct euro_mod:units::modifier_base<dollar_mod>{};
struct yen_mod:units::modifier_base<dollar_mod>{};

// Define a modifier modifier
template<class Currency>
struct cent:units::modifier_base<Currency>{};
	
// Define the static conversions
template<class Currency, class Converter>
void convert(cent<Currency>, Currency, double&num, const Converter&){
	num /= 100;
}

template<class Currency, class Converter>
void convert(Currency, cent<Currency>, double&num, const Converter&){
	num *= 100;
}
	
// Define the dynamic conversions
class money_converter:public units::converter<money_converter>{
public:
	money_converter(double euro_course, double yen_course):
		euro_course(euro_course), yen_course(yen_course){}

	using units::converter<money_converter>::convert;

	void convert(dollar_mod, euro_mod, double&num)const{
		num *= euro_course;
	}

	void convert(dollar_mod, yen_mod, double&num)const{
		num *= yen_course;
	}

	void convert(euro_mod, dollar_mod, double&num)const{
		num /= euro_course;
	}

	void convert(yen_mod, dollar_mod, double&num)const{
		num /= yen_course;
	}		
private:
	double euro_course;
	double yen_course;
};

// Define the units
typedef units::unit<money, dollar_mod> dollar;
typedef units::unit<money, euro_mod> euro;
typedef units::unit<money, yen_mod> yen;

typedef units::unit<money, cent<dollar_mod> > dollar_cent;
typedef units::unit<money, cent<euro_mod> > euro_cent;

std::ostream&operator<<(std::ostream&out, dollar n) { return out<<n.raw()<<" dollar"; }
std::ostream&operator<<(std::ostream&out, euro n) { return out<<n.raw()<<" euro"; }
std::ostream&operator<<(std::ostream&out, yen n) { return out<<n.raw()<<" yen"; }
std::ostream&operator<<(std::ostream&out, dollar_cent n) { return out<<n.raw()<<" dollar cent"; }
std::ostream&operator<<(std::ostream&out, euro_cent n) { return out<<n.raw()<<" euro cent"; }

int main(){
	using std::cout;
	using std::endl;
	using std::cin;
	using units::unit_cast;
	
	dollar amount(1);
	cout<<"How many dollars do you have ? : ";
	cin>>amount.raw();
	cout<<"That's "<<unit_cast<dollar_cent>(amount)<<std::endl; 
	double euro_course = 0.7, yen_course = 70;
	cout<<"How many euro is one dollar ? : ";
	cin>>euro_course;
	cout<<"How many yen is one dollar ? : ";
	cin>>yen_course;
	money_converter converter(euro_course, yen_course);
	cout<<"You have : "<<endl;
	cout<<unit_cast<euro>(amount, converter)<<endl
		<<unit_cast<euro_cent>(amount, converter)<<endl
		<<unit_cast<yen>(amount, converter)<<endl;
	cout<<" EXIT "<<endl;
}
